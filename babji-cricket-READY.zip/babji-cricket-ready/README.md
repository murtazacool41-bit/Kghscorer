# 🏏 Babji Cricket — Deployment Guide

## Prerequisites
- Node.js 18+
- Firebase account (free tier works)
- Git

---

## Step 1 — Firebase Project Setup

1. Go to [https://console.firebase.google.com](https://console.firebase.google.com)
2. Click **Add project** → Name it `babji-cricket`
3. Disable Google Analytics (optional) → **Create project**

### Enable Authentication
1. Go to **Authentication** → **Get started**
2. Click **Sign-in method**
3. Enable **Google** → add your support email → Save
4. Enable **Email/Password** → Save

### Enable Firestore
1. Go to **Firestore Database** → **Create database**
2. Choose **Start in production mode** → Select your region → **Enable**

### Enable Storage
1. Go to **Storage** → **Get started**
2. Accept default rules → Choose region → **Done**

### Get Firebase Config
1. Go to **Project Settings** (gear icon) → **General**
2. Scroll to **Your apps** → Click **</>** (Web)
3. Register app as `babji-cricket-web`
4. Copy the `firebaseConfig` object values

---

## Step 2 — Local Setup

```bash
# Clone or extract the project
cd babji-cricket

# Install dependencies
npm install

# Copy environment file
cp .env.example .env.local

# Edit .env.local with your Firebase values
nano .env.local   # or open in any editor
```

Fill in `.env.local`:
```
NEXT_PUBLIC_FIREBASE_API_KEY=AIzaSy...
NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN=babji-cricket.firebaseapp.com
NEXT_PUBLIC_FIREBASE_PROJECT_ID=babji-cricket
NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET=babji-cricket.appspot.com
NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID=123456789
NEXT_PUBLIC_FIREBASE_APP_ID=1:123456789:web:abc123
```

---

## Step 3 — Test Locally

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000)

---

## Step 4 — Deploy to Firebase Hosting

### Install Firebase CLI
```bash
npm install -g firebase-tools
```

### Login and Initialize
```bash
firebase login
firebase use --add
# Select your babji-cricket project
```

### Build and Export
```bash
npm run build
```

> Note: For Firebase Hosting with Next.js, use static export.
> Add this to `next.config.js`:
> ```js
> const nextConfig = {
>   output: 'export',
>   // ... rest of config
> }
> ```

### Deploy
```bash
firebase deploy
```

Your site will be live at:
**https://babji-cricket.web.app** (or your custom project ID)

---

## Step 5 — Deploy Firestore Rules & Indexes

```bash
firebase deploy --only firestore
```

---

## Step 6 — Make Yourself Admin

After signing up on the site:

1. Go to **Firebase Console** → **Firestore Database**
2. Find the `users` collection
3. Find your user document (by email)
4. Edit the `role` field → change from `user` to `admin`
5. Save

Now you have full admin access on the site.

---

## Step 7 — Set Up Google Auth Domain

1. Firebase Console → **Authentication** → **Settings** → **Authorized domains**
2. Add your domain: `babji-cricket.web.app`

---

## Firestore Collections Schema

```
users/
  {uid}/
    email, displayName, photoURL, role, createdAt

teams/
  {teamId}/
    name, logoURL, captainId, captainName, description
    playerIds[], createdBy, stats{...}

players/
  {playerId}/
    name, photoURL, battingStyle, bowlingStyle, role
    teamId, teamName, battingStats{...}, bowlingStats{...}, fieldingStats{...}

tournaments/
  {tournamentId}/
    name, startDate, endDate, format, overs, status, teamIds[]

matches/
  {matchId}/
    teamA{id,name,logoURL}, teamB{...}, ground, date, overs
    tournamentId, status, tossWinnerId, battingFirstTeamId
    innings1{...}, innings2{...}, result{...}

innings/
  {inningsId}/
    matchId, inningsNumber, battingTeamId, bowlingTeamId
    runs, wickets, overs, balls, extras{...}
    batters[...], bowlers[...], targetRuns, requiredRunRate

ballEvents/
  {eventId}/
    matchId, inningsId, overNumber, ballNumber
    batsmanId, bowlerId, runs, extraType, isWicket
    dismissalType, fielderId, isBoundary, isSix

pointsTable/
  {entryId}/
    tournamentId, teamId, teamName, matchesPlayed
    wins, losses, ties, points, netRunRate
```

---

## User Roles

| Role | Can Do |
|------|--------|
| **user** | View everything, sign in |
| **scorer** | Create matches, score live, create teams/players |
| **admin** | Everything + manage users, delete records |

---

## Live Score Sharing

Every match has a public URL:
```
https://babji-cricket.web.app/matches/{matchId}
```

Share this link — anyone can view the live score without signing in.

---

## PDF Scorecard

On any completed match page, click the **PDF** button to download a formatted scorecard with full batting/bowling figures.

---

## Custom Domain (Optional)

1. Firebase Console → **Hosting** → **Add custom domain**
2. Enter your domain (e.g. `cricket.yourdomain.com`)
3. Follow DNS verification steps

---

## Troubleshooting

**Build errors**: Make sure all `.env.local` values are filled correctly.

**Auth not working**: Check that your domain is in Firebase authorized domains list.

**Firestore permission denied**: Deploy the security rules: `firebase deploy --only firestore:rules`

**Images not loading**: Firebase Storage CORS may need configuration for custom domains.

---

## Tech Stack

- **Frontend**: Next.js 15, React 18, Tailwind CSS
- **Backend**: Firebase (Auth, Firestore, Storage, Hosting)
- **Realtime**: Firestore onSnapshot listeners
- **PDF**: jsPDF + jsPDF-AutoTable
- **Icons**: Lucide React
- **Fonts**: Rajdhani (display), DM Sans (body)
