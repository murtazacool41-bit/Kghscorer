'use client';
import { useState } from 'react';
import PlayerSearchInput from './PlayerSearchInput';
import type { Player } from '@/types';
import { X, Users, CheckCircle } from 'lucide-react';

interface SquadBuilderProps {
  teamName: string;
  maxPlayers?: number;
  onSquadChange: (players: Player[]) => void;
  initialPlayers?: Player[];
}

export default function SquadBuilder({
  teamName,
  maxPlayers = 11,
  onSquadChange,
  initialPlayers = [],
}: SquadBuilderProps) {
  const [squad, setSquad] = useState<Player[]>(initialPlayers);

  const addPlayer = (player: Player) => {
    if (squad.find(p => p.id === player.id)) return; // no duplicates
    if (squad.length >= maxPlayers) return;
    const updated = [...squad, player];
    setSquad(updated);
    onSquadChange(updated);
  };

  const removePlayer = (playerId: string) => {
    const updated = squad.filter(p => p.id !== playerId);
    setSquad(updated);
    onSquadChange(updated);
  };

  const isComplete = squad.length === maxPlayers;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="font-display font-semibold text-base flex items-center gap-2">
          <Users className="w-4 h-4 text-primary" />
          {teamName} — Playing XI
        </h3>
        <span className={`text-sm font-mono font-bold px-2 py-0.5 rounded-full ${
          isComplete ? 'bg-green-500/10 text-green-500' : 'bg-muted text-muted-foreground'
        }`}>
          {squad.length}/{maxPlayers}
        </span>
      </div>

      {/* Player list */}
      {squad.length > 0 && (
        <div className="space-y-1.5">
          {squad.map((player, idx) => (
            <div
              key={player.id}
              className="flex items-center gap-3 px-3 py-2 rounded-lg bg-muted/50 border border-border/50"
            >
              <span className="text-xs font-mono text-muted-foreground w-5 text-center">{idx + 1}</span>
              {player.photoURL ? (
                <img src={player.photoURL} alt="" className="w-7 h-7 rounded-full object-cover" />
              ) : (
                <div className="w-7 h-7 rounded-full bg-muted flex items-center justify-center text-sm font-bold text-muted-foreground">
                  {player.name[0]}
                </div>
              )}
              <div className="flex-1 min-w-0">
                <span className="text-sm font-medium truncate block">{player.name}</span>
                <span className="text-xs text-muted-foreground">{player.role}</span>
              </div>
              <button
                type="button"
                onClick={() => removePlayer(player.id)}
                className="p-1 rounded hover:bg-destructive/10 text-muted-foreground hover:text-destructive transition-colors"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          ))}
        </div>
      )}

      {/* Completion badge */}
      {isComplete ? (
        <div className="flex items-center gap-2 p-3 rounded-xl bg-green-500/10 border border-green-500/20 text-green-600 text-sm font-medium">
          <CheckCircle className="w-4 h-4" />
          Playing XI complete!
        </div>
      ) : (
        <PlayerSearchInput
          placeholder={`Add player ${squad.length + 1}...`}
          excludeIds={squad.map(p => p.id)}
          onSelect={(p) => {
            if ('isNew' in p) {
              // Shouldn't happen with our auto-save, but handle gracefully
              return;
            }
            addPlayer(p as Player);
          }}
        />
      )}
    </div>
  );
}
