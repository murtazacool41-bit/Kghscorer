'use client';
import { useState, useEffect, useRef } from 'react';
import { collection, getDocs, addDoc, query, where, orderBy, serverTimestamp } from 'firebase/firestore';
import { db } from '@/lib/firebase';
import type { Player } from '@/types';
import { Search, Plus, User, Check } from 'lucide-react';

interface PlayerSearchInputProps {
  onSelect: (player: Player | { name: string; isNew: true }) => void;
  placeholder?: string;
  teamId?: string;
  excludeIds?: string[];
  label?: string;
  required?: boolean;
}

export default function PlayerSearchInput({
  onSelect,
  placeholder = 'Type player name...',
  teamId,
  excludeIds = [],
  label,
  required,
}: PlayerSearchInputProps) {
  const [query_, setQuery] = useState('');
  const [results, setResults] = useState<Player[]>([]);
  const [allPlayers, setAllPlayers] = useState<Player[]>([]);
  const [open, setOpen] = useState(false);
  const [selected, setSelected] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Load all players once on mount
  useEffect(() => {
    const loadPlayers = async () => {
      setLoading(true);
      try {
        const snap = await getDocs(collection(db, 'players'));
        const players = snap.docs.map(d => ({ id: d.id, ...d.data() }) as Player);
        setAllPlayers(players);
      } finally {
        setLoading(false);
      }
    };
    loadPlayers();
  }, []);

  // Filter on input
  useEffect(() => {
    if (!query_.trim()) {
      setResults([]);
      setOpen(false);
      return;
    }
    const q = query_.toLowerCase().trim();
    const filtered = allPlayers
      .filter(p => !excludeIds.includes(p.id))
      .filter(p => p.name.toLowerCase().includes(q))
      .slice(0, 8);
    setResults(filtered);
    setOpen(true);
  }, [query_, allPlayers, excludeIds]);

  // Close on outside click
  useEffect(() => {
    const handleClick = (e: MouseEvent) => {
      if (!dropdownRef.current?.contains(e.target as Node) && !inputRef.current?.contains(e.target as Node)) {
        setOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClick);
    return () => document.removeEventListener('mousedown', handleClick);
  }, []);

  const handleSelect = (player: Player) => {
    setQuery(player.name);
    setSelected(player.id);
    setOpen(false);
    onSelect(player);
  };

  const handleCreateNew = async () => {
    if (!query_.trim()) return;
    const name = query_.trim();

    // Check exact match first
    const exact = allPlayers.find(p => p.name.toLowerCase() === name.toLowerCase());
    if (exact) {
      handleSelect(exact);
      return;
    }

    // Auto-create the player
    const newPlayerData = {
      name,
      battingStyle: 'Right Handed',
      role: 'Batsman',
      teamId: teamId || null,
      createdBy: 'auto',
      battingStats: { matches: 0, innings: 0, runs: 0, highestScore: 0, highestScoreNotOut: false, notOuts: 0, average: 0, strikeRate: 0, fours: 0, sixes: 0, fifties: 0, hundreds: 0, ducks: 0 },
      bowlingStats: { matches: 0, innings: 0, overs: 0, balls: 0, maidens: 0, runs: 0, wickets: 0, bestBowlingWickets: 0, bestBowlingRuns: 999, average: 0, economy: 0, strikeRate: 0, fourWickets: 0, fiveWickets: 0 },
      fieldingStats: { catches: 0, runOuts: 0, stumpings: 0 },
      createdAt: serverTimestamp(),
    };

    try {
      const docRef = await addDoc(collection(db, 'players'), newPlayerData);
      const saved: Player = { id: docRef.id, ...newPlayerData } as any;
      setAllPlayers(prev => [...prev, saved]);
      setSelected(docRef.id);
      setOpen(false);
      onSelect(saved);
    } catch (err) {
      console.error('Failed to save player:', err);
      onSelect({ name, isNew: true });
    }
  };

  const exactMatch = allPlayers.some(p => p.name.toLowerCase() === query_.toLowerCase().trim());
  const showCreateOption = query_.trim().length > 1 && !exactMatch && open;

  return (
    <div className="relative">
      {label && (
        <label className="block text-sm font-medium mb-1.5">
          {label} {required && <span className="text-destructive">*</span>}
        </label>
      )}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
        <input
          ref={inputRef}
          type="text"
          value={query_}
          onChange={e => { setQuery(e.target.value); setSelected(null); }}
          onFocus={() => { if (query_.trim()) setOpen(true); }}
          placeholder={placeholder}
          className={`w-full pl-10 pr-10 py-2.5 rounded-xl border bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring transition-colors ${
            selected ? 'border-primary' : 'border-input'
          }`}
        />
        {selected && (
          <Check className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-primary" />
        )}
      </div>

      {/* Dropdown */}
      {open && (results.length > 0 || showCreateOption) && (
        <div
          ref={dropdownRef}
          className="absolute z-50 top-full left-0 right-0 mt-1 rounded-xl border border-border bg-popover shadow-lg overflow-hidden"
        >
          {results.map(player => (
            <button
              key={player.id}
              type="button"
              onMouseDown={() => handleSelect(player)}
              className="w-full flex items-center gap-3 px-3 py-2.5 hover:bg-muted transition-colors text-left"
            >
              {player.photoURL ? (
                <img src={player.photoURL} alt="" className="w-8 h-8 rounded-full object-cover shrink-0" />
              ) : (
                <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center shrink-0">
                  <User className="w-4 h-4 text-muted-foreground" />
                </div>
              )}
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium truncate">{player.name}</p>
                <p className="text-xs text-muted-foreground truncate">
                  {player.role} {player.teamName ? `• ${player.teamName}` : ''}
                  {player.battingStats.runs > 0 ? ` • ${player.battingStats.runs} runs` : ''}
                </p>
              </div>
              {player.battingStats.matches > 0 && (
                <span className="text-xs text-muted-foreground shrink-0">{player.battingStats.matches}M</span>
              )}
            </button>
          ))}

          {showCreateOption && (
            <>
              {results.length > 0 && <div className="border-t border-border" />}
              <button
                type="button"
                onMouseDown={handleCreateNew}
                className="w-full flex items-center gap-3 px-3 py-2.5 hover:bg-primary/10 transition-colors text-left text-primary"
              >
                <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                  <Plus className="w-4 h-4" />
                </div>
                <div>
                  <p className="text-sm font-medium">Add "{query_.trim()}"</p>
                  <p className="text-xs text-muted-foreground">New player — saved automatically</p>
                </div>
              </button>
            </>
          )}
        </div>
      )}

      {/* Helper text when nothing typed yet */}
      {!query_ && !selected && (
        <p className="text-xs text-muted-foreground mt-1">
          Type a name to search saved players or create new
        </p>
      )}
    </div>
  );
}
