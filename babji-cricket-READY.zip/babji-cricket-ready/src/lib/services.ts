import {
  collection,
  doc,
  getDoc,
  getDocs,
  addDoc,
  updateDoc,
  deleteDoc,
  query,
  where,
  orderBy,
  limit,
  onSnapshot,
  serverTimestamp,
  increment,
  writeBatch,
  Timestamp,
  DocumentSnapshot,
} from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL, deleteObject } from 'firebase/storage';
import { db, storage } from './firebase';
import type { Team, Player, Match, Innings, BallEvent, Tournament, PointsTableEntry, User } from '@/types';

// ============ USER SERVICES ============
export async function getUser(userId: string): Promise<User | null> {
  const snap = await getDoc(doc(db, 'users', userId));
  if (!snap.exists()) return null;
  return { id: snap.id, ...snap.data() } as User;
}

export async function createOrUpdateUser(userId: string, data: Partial<User>) {
  await updateDoc(doc(db, 'users', userId), { ...data, updatedAt: serverTimestamp() }).catch(async () => {
    await addDoc(collection(db, 'users'), { id: userId, ...data, createdAt: serverTimestamp() });
  });
}

export async function setUserRole(userId: string, role: string) {
  await updateDoc(doc(db, 'users', userId), { role });
}

export async function getAllUsers() {
  const snap = await getDocs(collection(db, 'users'));
  return snap.docs.map(d => ({ id: d.id, ...d.data() }) as User);
}

// ============ TEAM SERVICES ============
export async function createTeam(data: Omit<Team, 'id' | 'createdAt' | 'stats'>) {
  const ref = await addDoc(collection(db, 'teams'), {
    ...data,
    stats: { matchesPlayed: 0, wins: 0, losses: 0, ties: 0, noResult: 0, winPercentage: 0, runsScored: 0, wicketsTaken: 0 },
    createdAt: serverTimestamp(),
  });
  return ref.id;
}

export async function getTeam(teamId: string): Promise<Team | null> {
  const snap = await getDoc(doc(db, 'teams', teamId));
  if (!snap.exists()) return null;
  return { id: snap.id, ...snap.data() } as Team;
}

export async function getAllTeams(): Promise<Team[]> {
  const snap = await getDocs(query(collection(db, 'teams'), orderBy('name')));
  return snap.docs.map(d => ({ id: d.id, ...d.data() }) as Team);
}

export async function updateTeam(teamId: string, data: Partial<Team>) {
  await updateDoc(doc(db, 'teams', teamId), { ...data, updatedAt: serverTimestamp() });
}

export async function deleteTeam(teamId: string) {
  await deleteDoc(doc(db, 'teams', teamId));
}

export function subscribeToTeam(teamId: string, callback: (team: Team | null) => void) {
  return onSnapshot(doc(db, 'teams', teamId), snap => {
    if (!snap.exists()) callback(null);
    else callback({ id: snap.id, ...snap.data() } as Team);
  });
}

// ============ PLAYER SERVICES ============
export async function createPlayer(data: Omit<Player, 'id' | 'createdAt' | 'battingStats' | 'bowlingStats' | 'fieldingStats'>) {
  const ref = await addDoc(collection(db, 'players'), {
    ...data,
    battingStats: { matches: 0, innings: 0, runs: 0, highestScore: 0, highestScoreNotOut: false, notOuts: 0, average: 0, strikeRate: 0, fours: 0, sixes: 0, fifties: 0, hundreds: 0, ducks: 0 },
    bowlingStats: { matches: 0, innings: 0, overs: 0, balls: 0, maidens: 0, runs: 0, wickets: 0, bestBowlingWickets: 0, bestBowlingRuns: 999, average: 0, economy: 0, strikeRate: 0, fourWickets: 0, fiveWickets: 0 },
    fieldingStats: { catches: 0, runOuts: 0, stumpings: 0 },
    createdAt: serverTimestamp(),
  });
  return ref.id;
}

export async function getPlayer(playerId: string): Promise<Player | null> {
  const snap = await getDoc(doc(db, 'players', playerId));
  if (!snap.exists()) return null;
  return { id: snap.id, ...snap.data() } as Player;
}

export async function getAllPlayers(): Promise<Player[]> {
  const snap = await getDocs(query(collection(db, 'players'), orderBy('name')));
  return snap.docs.map(d => ({ id: d.id, ...d.data() }) as Player);
}

export async function getPlayersByTeam(teamId: string): Promise<Player[]> {
  const snap = await getDocs(query(collection(db, 'players'), where('teamId', '==', teamId)));
  return snap.docs.map(d => ({ id: d.id, ...d.data() }) as Player);
}

export async function updatePlayer(playerId: string, data: Partial<Player>) {
  await updateDoc(doc(db, 'players', playerId), { ...data, updatedAt: serverTimestamp() });
}

export async function deletePlayer(playerId: string) {
  await deleteDoc(doc(db, 'players', playerId));
}

// ============ TOURNAMENT SERVICES ============
export async function createTournament(data: Omit<Tournament, 'id' | 'createdAt'>) {
  const ref = await addDoc(collection(db, 'tournaments'), {
    ...data,
    status: 'upcoming',
    teamIds: [],
    createdAt: serverTimestamp(),
  });
  return ref.id;
}

export async function getTournament(id: string): Promise<Tournament | null> {
  const snap = await getDoc(doc(db, 'tournaments', id));
  if (!snap.exists()) return null;
  return { id: snap.id, ...snap.data() } as Tournament;
}

export async function getAllTournaments(): Promise<Tournament[]> {
  const snap = await getDocs(query(collection(db, 'tournaments'), orderBy('createdAt', 'desc')));
  return snap.docs.map(d => ({ id: d.id, ...d.data() }) as Tournament);
}

export async function updateTournament(id: string, data: Partial<Tournament>) {
  await updateDoc(doc(db, 'tournaments', id), { ...data, updatedAt: serverTimestamp() });
}

export async function addTeamToTournament(tournamentId: string, teamId: string) {
  const t = await getTournament(tournamentId);
  if (!t) return;
  const teamIds = [...(t.teamIds || []), teamId];
  await updateDoc(doc(db, 'tournaments', tournamentId), { teamIds });
  // Create points table entry
  const team = await getTeam(teamId);
  if (team) {
    await addDoc(collection(db, 'pointsTable'), {
      tournamentId,
      teamId,
      teamName: team.name,
      teamLogoURL: team.logoURL || null,
      matchesPlayed: 0, wins: 0, losses: 0, ties: 0, noResult: 0,
      points: 0, runsScored: 0, runsConceded: 0, oversFaced: 0, oversBowled: 0, netRunRate: 0,
    });
  }
}

export async function getTournamentPointsTable(tournamentId: string): Promise<PointsTableEntry[]> {
  const snap = await getDocs(query(
    collection(db, 'pointsTable'),
    where('tournamentId', '==', tournamentId),
    orderBy('points', 'desc'),
    orderBy('netRunRate', 'desc')
  ));
  return snap.docs.map(d => ({ id: d.id, ...d.data() }) as PointsTableEntry);
}

// ============ MATCH SERVICES ============
export async function createMatch(data: Omit<Match, 'id' | 'createdAt' | 'status' | 'currentInnings'>) {
  const ref = await addDoc(collection(db, 'matches'), {
    ...data,
    status: 'upcoming',
    currentInnings: 1,
    createdAt: serverTimestamp(),
  });
  return ref.id;
}

export async function getMatch(matchId: string): Promise<Match | null> {
  const snap = await getDoc(doc(db, 'matches', matchId));
  if (!snap.exists()) return null;
  return { id: snap.id, ...snap.data() } as Match;
}

export async function getAllMatches(): Promise<Match[]> {
  const snap = await getDocs(query(collection(db, 'matches'), orderBy('createdAt', 'desc')));
  return snap.docs.map(d => ({ id: d.id, ...d.data() }) as Match);
}

export async function getLiveMatches(): Promise<Match[]> {
  const snap = await getDocs(query(collection(db, 'matches'), where('status', '==', 'live')));
  return snap.docs.map(d => ({ id: d.id, ...d.data() }) as Match);
}

export async function getUpcomingMatches(): Promise<Match[]> {
  const snap = await getDocs(query(
    collection(db, 'matches'),
    where('status', 'in', ['upcoming', 'toss']),
    orderBy('date'),
    limit(10)
  ));
  return snap.docs.map(d => ({ id: d.id, ...d.data() }) as Match);
}

export async function getRecentMatches(): Promise<Match[]> {
  const snap = await getDocs(query(
    collection(db, 'matches'),
    where('status', '==', 'completed'),
    orderBy('date', 'desc'),
    limit(10)
  ));
  return snap.docs.map(d => ({ id: d.id, ...d.data() }) as Match);
}

export async function updateMatch(matchId: string, data: Partial<Match>) {
  await updateDoc(doc(db, 'matches', matchId), { ...data, updatedAt: serverTimestamp() });
}

export function subscribeToMatch(matchId: string, callback: (match: Match | null) => void) {
  return onSnapshot(doc(db, 'matches', matchId), snap => {
    if (!snap.exists()) callback(null);
    else callback({ id: snap.id, ...snap.data() } as Match);
  });
}

// ============ INNINGS SERVICES ============
export async function createInnings(data: Omit<Innings, 'id'>) {
  const ref = await addDoc(collection(db, 'innings'), data);
  return ref.id;
}

export async function getInnings(inningsId: string): Promise<Innings | null> {
  const snap = await getDoc(doc(db, 'innings', inningsId));
  if (!snap.exists()) return null;
  return { id: snap.id, ...snap.data() } as Innings;
}

export async function getMatchInnings(matchId: string): Promise<Innings[]> {
  const snap = await getDocs(query(
    collection(db, 'innings'),
    where('matchId', '==', matchId),
    orderBy('inningsNumber')
  ));
  return snap.docs.map(d => ({ id: d.id, ...d.data() }) as Innings);
}

export async function updateInnings(inningsId: string, data: Partial<Innings>) {
  await updateDoc(doc(db, 'innings', inningsId), data);
}

export function subscribeToInnings(inningsId: string, callback: (innings: Innings | null) => void) {
  return onSnapshot(doc(db, 'innings', inningsId), snap => {
    if (!snap.exists()) callback(null);
    else callback({ id: snap.id, ...snap.data() } as Innings);
  });
}

// ============ BALL EVENT SERVICES ============
export async function addBallEvent(data: Omit<BallEvent, 'id'>) {
  const ref = await addDoc(collection(db, 'ballEvents'), {
    ...data,
    timestamp: serverTimestamp(),
  });
  return ref.id;
}

export async function getInningsBallEvents(inningsId: string): Promise<BallEvent[]> {
  const snap = await getDocs(query(
    collection(db, 'ballEvents'),
    where('inningsId', '==', inningsId),
    orderBy('overNumber'),
    orderBy('ballNumber')
  ));
  return snap.docs.map(d => ({ id: d.id, ...d.data() }) as BallEvent);
}

export function subscribeToBallEvents(inningsId: string, callback: (events: BallEvent[]) => void) {
  return onSnapshot(
    query(collection(db, 'ballEvents'), where('inningsId', '==', inningsId), orderBy('timestamp')),
    snap => callback(snap.docs.map(d => ({ id: d.id, ...d.data() }) as BallEvent))
  );
}

// ============ LEADERBOARD SERVICES ============
export async function getTopRunScorers(limitCount = 10) {
  const snap = await getDocs(query(
    collection(db, 'players'),
    orderBy('battingStats.runs', 'desc'),
    limit(limitCount)
  ));
  return snap.docs.map(d => ({ id: d.id, ...d.data() }) as Player);
}

export async function getTopWicketTakers(limitCount = 10) {
  const snap = await getDocs(query(
    collection(db, 'players'),
    orderBy('bowlingStats.wickets', 'desc'),
    limit(limitCount)
  ));
  return snap.docs.map(d => ({ id: d.id, ...d.data() }) as Player);
}

// ============ STORAGE SERVICES ============
export async function uploadImage(file: File, path: string): Promise<string> {
  const storageRef = ref(storage, path);
  await uploadBytes(storageRef, file);
  return getDownloadURL(storageRef);
}

export async function uploadTeamLogo(teamId: string, file: File): Promise<string> {
  return uploadImage(file, `teams/${teamId}/logo`);
}

export async function uploadPlayerPhoto(playerId: string, file: File): Promise<string> {
  return uploadImage(file, `players/${playerId}/photo`);
}

// ============ STATS UPDATE SERVICES ============
export async function updatePlayerStatsAfterMatch(
  playerId: string,
  battingData: Partial<Player['battingStats']>,
  bowlingData: Partial<Player['bowlingStats']>,
  fieldingData: Partial<Player['fieldingStats']>
) {
  const player = await getPlayer(playerId);
  if (!player) return;

  const newBattingStats = { ...player.battingStats };
  const newBowlingStats = { ...player.bowlingStats };
  const newFieldingStats = { ...player.fieldingStats };

  if (battingData.runs !== undefined) {
    newBattingStats.runs += battingData.runs;
    newBattingStats.innings += 1;
    newBattingStats.matches += 1;
    newBattingStats.fours += battingData.fours || 0;
    newBattingStats.sixes += battingData.sixes || 0;
    if (battingData.runs > newBattingStats.highestScore) {
      newBattingStats.highestScore = battingData.runs;
      newBattingStats.highestScoreNotOut = battingData.notOuts === 1;
    }
    if (battingData.notOuts) newBattingStats.notOuts += 1;
    const dismissals = newBattingStats.innings - newBattingStats.notOuts;
    newBattingStats.average = dismissals > 0 ? newBattingStats.runs / dismissals : newBattingStats.runs;
    if (battingData.runs >= 100) newBattingStats.hundreds += 1;
    else if (battingData.runs >= 50) newBattingStats.fifties += 1;
    if (battingData.runs === 0 && battingData.notOuts !== 1) newBattingStats.ducks += 1;
  }

  if (bowlingData.wickets !== undefined) {
    newBowlingStats.wickets += bowlingData.wickets;
    newBowlingStats.runs += bowlingData.runs || 0;
    newBowlingStats.overs += bowlingData.overs || 0;
    newBowlingStats.maidens += bowlingData.maidens || 0;
    newBowlingStats.economy = newBowlingStats.overs > 0 ? newBowlingStats.runs / newBowlingStats.overs : 0;
  }

  if (fieldingData.catches !== undefined) newFieldingStats.catches += fieldingData.catches;
  if (fieldingData.runOuts !== undefined) newFieldingStats.runOuts += fieldingData.runOuts;
  if (fieldingData.stumpings !== undefined) newFieldingStats.stumpings += fieldingData.stumpings;

  await updatePlayer(playerId, {
    battingStats: newBattingStats,
    bowlingStats: newBowlingStats,
    fieldingStats: newFieldingStats,
  });
}

export async function updateTeamStatsAfterMatch(teamId: string, won: boolean, lost: boolean, tied: boolean) {
  const team = await getTeam(teamId);
  if (!team) return;
  const stats = { ...team.stats };
  stats.matchesPlayed += 1;
  if (won) stats.wins += 1;
  else if (lost) stats.losses += 1;
  else if (tied) stats.ties += 1;
  stats.winPercentage = stats.matchesPlayed > 0 ? (stats.wins / stats.matchesPlayed) * 100 : 0;
  await updateTeam(teamId, { stats });
}

export async function updatePointsTable(tournamentId: string, teamId: string, won: boolean, lost: boolean, tied: boolean, noResult: boolean, runsScored: number, runsConceded: number, oversFaced: number, oversBowled: number) {
  const snap = await getDocs(query(
    collection(db, 'pointsTable'),
    where('tournamentId', '==', tournamentId),
    where('teamId', '==', teamId)
  ));
  if (snap.empty) return;
  const docRef = snap.docs[0].ref;
  const entry = snap.docs[0].data() as PointsTableEntry;
  const newEntry = {
    matchesPlayed: entry.matchesPlayed + 1,
    wins: entry.wins + (won ? 1 : 0),
    losses: entry.losses + (lost ? 1 : 0),
    ties: entry.ties + (tied ? 1 : 0),
    noResult: entry.noResult + (noResult ? 1 : 0),
    points: entry.points + (won ? 2 : tied ? 1 : 0),
    runsScored: entry.runsScored + runsScored,
    runsConceded: entry.runsConceded + runsConceded,
    oversFaced: entry.oversFaced + oversFaced,
    oversBowled: entry.oversBowled + oversBowled,
  };
  const nrr = newEntry.oversFaced > 0 && newEntry.oversBowled > 0
    ? (newEntry.runsScored / newEntry.oversFaced) - (newEntry.runsConceded / newEntry.oversBowled)
    : 0;
  await updateDoc(docRef, { ...newEntry, netRunRate: parseFloat(nrr.toFixed(3)) });
}
