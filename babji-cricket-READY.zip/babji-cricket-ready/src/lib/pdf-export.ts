import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import type { Match, Innings } from '@/types';

export async function generateScorecard(match: Match, innings1: Innings, innings2?: Innings) {
  const pdf = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });
  const pageWidth = pdf.internal.pageSize.getWidth();

  // Header
  pdf.setFillColor(10, 22, 40);
  pdf.rect(0, 0, pageWidth, 35, 'F');
  pdf.setTextColor(255, 215, 0);
  pdf.setFontSize(22);
  pdf.setFont('helvetica', 'bold');
  pdf.text('BABJI CRICKET', pageWidth / 2, 15, { align: 'center' });
  pdf.setFontSize(11);
  pdf.setTextColor(200, 200, 200);
  pdf.text('Official Scorecard', pageWidth / 2, 24, { align: 'center' });

  // Match Info
  pdf.setTextColor(0, 0, 0);
  pdf.setFontSize(14);
  pdf.setFont('helvetica', 'bold');
  pdf.text(`${match.teamA.name} vs ${match.teamB.name}`, pageWidth / 2, 48, { align: 'center' });

  pdf.setFontSize(9);
  pdf.setFont('helvetica', 'normal');
  pdf.text(`Ground: ${match.ground}`, 14, 56);
  pdf.text(`Overs: ${match.overs}`, pageWidth / 2, 56, { align: 'center' });
  if (match.tournamentName) {
    pdf.text(`Tournament: ${match.tournamentName}`, pageWidth - 14, 56, { align: 'right' });
  }

  if (match.result) {
    pdf.setFillColor(0, 165, 80);
    pdf.rect(14, 60, pageWidth - 28, 10, 'F');
    pdf.setTextColor(255, 255, 255);
    pdf.setFontSize(10);
    pdf.setFont('helvetica', 'bold');
    pdf.text(match.result.resultText, pageWidth / 2, 67, { align: 'center' });
  }

  let yPos = 78;

  // Innings function
  const addInnings = (innings: Innings, startY: number): number => {
    let y = startY;
    pdf.setTextColor(255, 255, 255);
    pdf.setFillColor(10, 22, 40);
    pdf.rect(14, y, pageWidth - 28, 8, 'F');
    pdf.setFontSize(10);
    pdf.setFont('helvetica', 'bold');
    pdf.text(`${innings.battingTeamId} INNINGS`, 18, y + 5.5);
    pdf.text(`${innings.runs}/${innings.wickets} (${innings.overs}.${innings.balls} Ov)`, pageWidth - 16, y + 5.5, { align: 'right' });
    y += 10;

    // Batting table
    pdf.setTextColor(0, 0, 0);
    pdf.setFontSize(8);
    pdf.setFont('helvetica', 'bold');
    pdf.text('BATTING', 14, y + 4);
    y += 6;

    autoTable(pdf, {
      startY: y,
      head: [['Batter', 'Dismissal', 'R', 'B', '4s', '6s', 'SR']],
      body: innings.batters.map(b => [
        b.playerName,
        b.isOut ? (b.dismissalDesc || 'out') : 'not out',
        b.runs.toString(),
        b.balls.toString(),
        b.fours.toString(),
        b.sixes.toString(),
        b.strikeRate.toFixed(1),
      ]),
      styles: { fontSize: 8, cellPadding: 2 },
      headStyles: { fillColor: [10, 22, 40], textColor: [255, 215, 0], fontStyle: 'bold' },
      alternateRowStyles: { fillColor: [245, 245, 245] },
      columnStyles: {
        0: { cellWidth: 45 },
        1: { cellWidth: 55 },
        2: { cellWidth: 12, halign: 'center' },
        3: { cellWidth: 12, halign: 'center' },
        4: { cellWidth: 10, halign: 'center' },
        5: { cellWidth: 10, halign: 'center' },
        6: { cellWidth: 20, halign: 'right' },
      },
      margin: { left: 14, right: 14 },
    });

    y = (pdf as any).lastAutoTable.finalY + 2;

    // Extras and Total
    pdf.setFontSize(8);
    pdf.setFont('helvetica', 'normal');
    pdf.text(`Extras: ${innings.extras.total} (W: ${innings.extras.wides}, NB: ${innings.extras.noBalls}, B: ${innings.extras.byes}, LB: ${innings.extras.legByes})`, 14, y + 4);
    pdf.setFont('helvetica', 'bold');
    pdf.text(`Total: ${innings.runs}/${innings.wickets} (${innings.overs}.${innings.balls} Overs)  RR: ${innings.runRate.toFixed(2)}`, pageWidth - 14, y + 4, { align: 'right' });
    y += 8;

    // Bowling table
    pdf.setFont('helvetica', 'bold');
    pdf.text('BOWLING', 14, y + 4);
    y += 6;

    autoTable(pdf, {
      startY: y,
      head: [['Bowler', 'O', 'M', 'R', 'W', 'Econ']],
      body: innings.bowlers.map(b => [
        b.playerName,
        `${b.overs}.${b.balls % 6}`,
        b.maidens.toString(),
        b.runs.toString(),
        b.wickets.toString(),
        b.economy.toFixed(2),
      ]),
      styles: { fontSize: 8, cellPadding: 2 },
      headStyles: { fillColor: [10, 22, 40], textColor: [255, 215, 0], fontStyle: 'bold' },
      alternateRowStyles: { fillColor: [245, 245, 245] },
      columnStyles: {
        0: { cellWidth: 55 },
        1: { cellWidth: 20, halign: 'center' },
        2: { cellWidth: 15, halign: 'center' },
        3: { cellWidth: 15, halign: 'center' },
        4: { cellWidth: 15, halign: 'center' },
        5: { cellWidth: 25, halign: 'right' },
      },
      margin: { left: 14, right: 14 },
    });

    return (pdf as any).lastAutoTable.finalY + 8;
  };

  yPos = addInnings(innings1, yPos);

  if (innings2) {
    if (yPos > 200) {
      pdf.addPage();
      yPos = 20;
    }
    yPos = addInnings(innings2, yPos);
  }

  // Footer
  pdf.setFontSize(7);
  pdf.setTextColor(150, 150, 150);
  pdf.setFont('helvetica', 'normal');
  pdf.text('Generated by Babji Cricket • babjicricket.web.app', pageWidth / 2, 290, { align: 'center' });

  pdf.save(`${match.teamA.name}_vs_${match.teamB.name}_scorecard.pdf`);
}
