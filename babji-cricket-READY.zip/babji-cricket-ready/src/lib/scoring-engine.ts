import { db } from './firebase';
import {
  doc, collection, addDoc, updateDoc, getDoc, getDocs,
  query, where, orderBy, serverTimestamp, writeBatch
} from 'firebase/firestore';
import type { Match, Innings, BallEvent, BatterInnings, BowlerInnings, DismissalType } from '@/types';

export interface ScoringAction {
  runs: number;
  extraType?: 'wide' | 'no_ball' | 'bye' | 'leg_bye';
  extraRuns?: number;
  isWicket?: boolean;
  dismissalType?: DismissalType;
  dismissedPlayerId?: string;
  dismissedPlayerName?: string;
  fielderId?: string;
  fielderName?: string;
}

export function formatOvers(overs: number, balls: number): string {
  return `${overs}.${balls}`;
}

export function calculateRunRate(runs: number, overs: number, balls: number): number {
  const totalOvers = overs + balls / 6;
  return totalOvers > 0 ? parseFloat((runs / totalOvers).toFixed(2)) : 0;
}

export function calculateRequiredRunRate(target: number, currentRuns: number, totalOvers: number, oversPlayed: number, ballsPlayed: number): number {
  const runsNeeded = target - currentRuns;
  const ballsRemaining = totalOvers * 6 - (oversPlayed * 6 + ballsPlayed);
  const oversRemaining = ballsRemaining / 6;
  return oversRemaining > 0 ? parseFloat((runsNeeded / oversRemaining).toFixed(2)) : 0;
}

export async function processDelivery(
  matchId: string,
  inningsId: string,
  innings: Innings,
  action: ScoringAction
): Promise<{ innings: Innings; isOverComplete: boolean; isInningsComplete: boolean }> {
  const batch = writeBatch(db);

  const isExtra = !!action.extraType;
  const isWideoOrNoBall = action.extraType === 'wide' || action.extraType === 'no_ball';
  const validDelivery = !isWideoOrNoBall;

  let newBalls = innings.balls;
  let newOvers = innings.overs;
  let isOverComplete = false;

  if (validDelivery) {
    newBalls = innings.balls + 1;
    if (newBalls >= 6) {
      newBalls = 0;
      newOvers = innings.overs + 1;
      isOverComplete = true;
    }
  }

  const totalRuns = action.runs + (action.extraRuns || 0);
  const newRuns = innings.runs + totalRuns;
  const newExtras = { ...innings.extras };

  if (action.extraType === 'wide') newExtras.wides += (action.extraRuns || 1);
  if (action.extraType === 'no_ball') newExtras.noBalls += 1;
  if (action.extraType === 'bye') newExtras.byes += action.runs;
  if (action.extraType === 'leg_bye') newExtras.legByes += action.runs;
  newExtras.total = newExtras.wides + newExtras.noBalls + newExtras.byes + newExtras.legByes;

  let newWickets = innings.wickets;
  if (action.isWicket) newWickets += 1;

  const newRunRate = calculateRunRate(newRuns, newOvers, newBalls);

  // Update batter stats
  const updatedBatters = innings.batters.map(b => {
    if (b.playerId === innings.strikerBatterId) {
      const runsToAdd = action.extraType === 'bye' || action.extraType === 'leg_bye' ? 0 : action.runs;
      const ballsToAdd = validDelivery ? 1 : 0;
      const newRuns = b.runs + runsToAdd;
      const newBalls = b.balls + ballsToAdd;
      const fours = action.runs === 4 && !isExtra ? b.fours + 1 : b.fours;
      const sixes = action.runs === 6 && !isExtra ? b.sixes + 1 : b.sixes;
      const strikeRate = newBalls > 0 ? parseFloat(((newRuns / newBalls) * 100).toFixed(2)) : 0;
      let isOut = b.isOut;
      let dismissalType = b.dismissalType;
      let dismissalDesc = b.dismissalDesc;

      if (action.isWicket && action.dismissedPlayerId === b.playerId) {
        isOut = true;
        dismissalType = action.dismissalType;
        dismissalDesc = buildDismissalDesc(action);
      }

      return { ...b, runs: newRuns, balls: newBalls, fours, sixes, strikeRate, isOut, dismissalType, dismissalDesc };
    }
    return b;
  });

  // Update bowler stats
  const updatedBowlers = innings.bowlers.map(b => {
    if (b.playerId === innings.currentBowlerId) {
      const newBalls = b.balls + (validDelivery ? 1 : 0);
      const newOvers = Math.floor(newBalls / 6);
      const remainingBalls = newBalls % 6;
      const runsToAdd = totalRuns;
      const newRuns = b.runs + runsToAdd;
      const totalOversDecimal = newOvers + remainingBalls / 6;
      const economy = totalOversDecimal > 0 ? parseFloat((newRuns / totalOversDecimal).toFixed(2)) : 0;
      const wickets = action.isWicket && action.dismissalType !== 'run_out' ? b.wickets + 1 : b.wickets;
      return { ...b, balls: newBalls, overs: newOvers, runs: newRuns, economy, wickets };
    }
    return b;
  });

  const maxOvers = await getMatchOvers(matchId);
  const isInningsComplete = newWickets >= 10 || newOvers >= maxOvers;

  // Build ball event
  const ballEvent: Omit<BallEvent, 'id'> = {
    matchId,
    inningsId,
    inningsNumber: innings.inningsNumber,
    overNumber: innings.overs,
    ballNumber: innings.balls,
    batsmanId: innings.strikerBatterId,
    batsmanName: innings.batters.find(b => b.playerId === innings.strikerBatterId)?.playerName || '',
    bowlerId: innings.currentBowlerId,
    bowlerName: innings.bowlers.find(b => b.playerId === innings.currentBowlerId)?.playerName || '',
    runs: action.runs,
    extraType: action.extraType,
    extraRuns: action.extraRuns || 0,
    isWicket: action.isWicket || false,
    dismissalType: action.dismissalType,
    dismissedPlayerId: action.dismissedPlayerId,
    dismissedPlayerName: action.dismissedPlayerName,
    fielderId: action.fielderId,
    fielderName: action.fielderName,
    isBoundary: action.runs === 4 && !isExtra,
    isSix: action.runs === 6 && !isExtra,
    timestamp: serverTimestamp() as any,
    totalRuns,
  };

  // Handle strike rotation
  let newStrikerId = innings.strikerBatterId;
  let newNonStrikerId = innings.nonStrikerBatterId;

  if (action.isWicket && action.dismissedPlayerId === innings.strikerBatterId) {
    // Striker dismissed - will need new batter
    newStrikerId = 'TBD';
  } else if (validDelivery && (action.runs % 2 === 1)) {
    // Odd runs - rotate strike
    [newStrikerId, newNonStrikerId] = [newNonStrikerId, newStrikerId];
  }

  // End of over - rotate strike
  if (isOverComplete) {
    [newStrikerId, newNonStrikerId] = [newNonStrikerId, newStrikerId];
  }

  const updatedInnings: Innings = {
    ...innings,
    runs: newRuns,
    wickets: newWickets,
    overs: newOvers,
    balls: newBalls,
    extras: newExtras,
    runRate: newRunRate,
    batters: updatedBatters,
    bowlers: updatedBowlers,
    strikerBatterId: newStrikerId,
    nonStrikerBatterId: newNonStrikerId,
    isCompleted: isInningsComplete,
    requiredRunRate: innings.targetRuns ? calculateRequiredRunRate(innings.targetRuns, newRuns, maxOvers, newOvers, newBalls) : undefined,
  };

  // Persist
  const inningsRef = doc(db, 'innings', inningsId);
  batch.update(inningsRef, {
    runs: newRuns, wickets: newWickets, overs: newOvers, balls: newBalls,
    extras: newExtras, runRate: newRunRate, batters: updatedBatters,
    bowlers: updatedBowlers, strikerBatterId: newStrikerId,
    nonStrikerBatterId: newNonStrikerId, isCompleted: isInningsComplete,
  });

  await batch.commit();
  await addDoc(collection(db, 'ballEvents'), ballEvent);

  return { innings: updatedInnings, isOverComplete, isInningsComplete };
}

function buildDismissalDesc(action: ScoringAction): string {
  switch (action.dismissalType) {
    case 'bowled': return 'b';
    case 'caught': return `c ${action.fielderName || ''}`;
    case 'run_out': return `run out (${action.fielderName || ''})`;
    case 'lbw': return 'lbw';
    case 'stumped': return `st ${action.fielderName || ''}`;
    case 'hit_wicket': return 'hit wicket';
    default: return '';
  }
}

async function getMatchOvers(matchId: string): Promise<number> {
  const snap = await getDoc(doc(db, 'matches', matchId));
  if (!snap.exists()) return 20;
  return snap.data().overs || 20;
}

export async function addNewBatter(inningsId: string, playerId: string, playerName: string, innings: Innings) {
  const newBatter: BatterInnings = {
    playerId,
    playerName,
    runs: 0, balls: 0, fours: 0, sixes: 0, strikeRate: 0,
    battingOrder: innings.batters.length + 1,
    isOut: false,
    isOnStrike: true,
  };

  const updatedBatters = [...innings.batters, newBatter];
  await updateDoc(doc(db, 'innings', inningsId), {
    batters: updatedBatters,
    strikerBatterId: playerId,
  });
}

export async function addNewBowler(inningsId: string, playerId: string, playerName: string, innings: Innings) {
  const existingBowler = innings.bowlers.find(b => b.playerId === playerId);
  
  // Mark current bowler as not bowling
  const updatedBowlers = innings.bowlers.map(b => ({ ...b, isBowling: false }));

  if (existingBowler) {
    const bowlerIdx = updatedBowlers.findIndex(b => b.playerId === playerId);
    updatedBowlers[bowlerIdx].isBowling = true;
    await updateDoc(doc(db, 'innings', inningsId), {
      bowlers: updatedBowlers,
      currentBowlerId: playerId,
    });
  } else {
    const newBowler: BowlerInnings = {
      playerId,
      playerName,
      overs: 0, balls: 0, maidens: 0, runs: 0, wickets: 0, wides: 0, noBalls: 0,
      economy: 0,
      bowlingOrder: innings.bowlers.length + 1,
      isBowling: true,
    };
    updatedBowlers.push(newBowler);
    await updateDoc(doc(db, 'innings', inningsId), {
      bowlers: updatedBowlers,
      currentBowlerId: playerId,
    });
  }
}
