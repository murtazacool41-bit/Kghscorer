import { initializeApp, getApps, getApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';
import { getStorage } from 'firebase/storage';

const firebaseConfig = {
  apiKey: "AIzaSyDlqlbp960yNlirkCuFpiT16a-NyjF-gjA",
  authDomain: "scorer-53d82.firebaseapp.com",
  projectId: "scorer-53d82",
  storageBucket: "scorer-53d82.firebasestorage.app",
  messagingSenderId: "382418066839",
  appId: "1:382418066839:web:58f61d5afb8a8c445178d2",
  measurementId: "G-DF225L4RT6"
};

const app = getApps().length ? getApp() : initializeApp(firebaseConfig);

export const auth = getAuth(app);
export const db = getFirestore(app);
export const storage = getStorage(app);

export default app;
