'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { getLiveMatches, getUpcomingMatches, getRecentMatches, getTopRunScorers, getTopWicketTakers, getAllTeams } from '@/lib/services';
import type { Match, Player, Team } from '@/types';
import { Zap, Clock, CheckCircle, TrendingUp, Award, Users, Trophy, ArrowRight, ChevronRight } from 'lucide-react';

export default function HomePage() {
  const [liveMatches, setLiveMatches] = useState<Match[]>([]);
  const [upcomingMatches, setUpcomingMatches] = useState<Match[]>([]);
  const [recentMatches, setRecentMatches] = useState<Match[]>([]);
  const [topBatsmen, setTopBatsmen] = useState<Player[]>([]);
  const [topBowlers, setTopBowlers] = useState<Player[]>([]);
  const [teams, setTeams] = useState<Team[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadData = async () => {
      try {
        const [live, upcoming, recent, batsmen, bowlers, allTeams] = await Promise.all([
          getLiveMatches(),
          getUpcomingMatches(),
          getRecentMatches(),
          getTopRunScorers(5),
          getTopWicketTakers(5),
          getAllTeams(),
        ]);
        setLiveMatches(live);
        setUpcomingMatches(upcoming);
        setRecentMatches(recent);
        setTopBatsmen(batsmen);
        setTopBowlers(bowlers);
        setTeams(allTeams);
      } finally {
        setLoading(false);
      }
    };
    loadData();
  }, []);

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-cricket-navy overflow-hidden py-16 sm:py-24">
        <div className="absolute inset-0 pitch-pattern opacity-30" />
        <div className="absolute top-0 right-0 w-1/2 h-full opacity-10">
          <svg viewBox="0 0 400 400" className="w-full h-full" fill="none">
            <circle cx="300" cy="200" r="180" stroke="#FFD700" strokeWidth="1" />
            <circle cx="300" cy="200" r="120" stroke="#00A550" strokeWidth="1" />
            <circle cx="300" cy="200" r="60" stroke="#FFD700" strokeWidth="1" />
          </svg>
        </div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6">
          <div className="max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cricket-gold/10 border border-cricket-gold/30 text-cricket-gold text-sm font-medium mb-6">
              <span className="w-2 h-2 rounded-full bg-cricket-gold animate-pulse" />
              Live Cricket Scoring Platform
            </div>
            <h1 className="font-display text-5xl sm:text-6xl font-bold text-white leading-tight mb-4">
              Your <span className="text-gradient-gold">Neighborhood</span><br />
              Cricket Hub
            </h1>
            <p className="text-white/70 text-lg mb-8 leading-relaxed">
              Track live scores, manage teams, and celebrate champions in your local cricket league.
            </p>
            <div className="flex flex-wrap gap-3">
              <Link href="/matches" className="px-6 py-3 rounded-xl bg-cricket-green text-white font-semibold hover:bg-green-600 transition-colors flex items-center gap-2">
                View Live Matches <ArrowRight className="w-4 h-4" />
              </Link>
              <Link href="/tournaments" className="px-6 py-3 rounded-xl bg-white/10 text-white font-semibold hover:bg-white/20 transition-colors border border-white/20">
                Tournaments
              </Link>
            </div>

            {/* Quick Stats */}
            <div className="grid grid-cols-3 gap-4 mt-12 max-w-sm">
              {[
                { label: 'Teams', value: teams.length },
                { label: 'Live Now', value: liveMatches.length },
                { label: 'Players', value: topBatsmen.length + topBowlers.length },
              ].map(s => (
                <div key={s.label} className="text-center">
                  <p className="font-display text-3xl font-bold text-white">{s.value}</p>
                  <p className="text-white/50 text-sm">{s.label}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-10 space-y-12">

        {/* Live Matches */}
        {liveMatches.length > 0 && (
          <section>
            <SectionHeader title="Live Matches" icon={<Zap className="w-5 h-5 text-red-500" />} href="/matches?status=live" />
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {liveMatches.map(match => (
                <LiveMatchCard key={match.id} match={match} />
              ))}
            </div>
          </section>
        )}

        {/* Upcoming Matches */}
        {upcomingMatches.length > 0 && (
          <section>
            <SectionHeader title="Upcoming Matches" icon={<Clock className="w-5 h-5 text-blue-500" />} href="/matches?status=upcoming" />
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {upcomingMatches.slice(0, 6).map(match => (
                <UpcomingMatchCard key={match.id} match={match} />
              ))}
            </div>
          </section>
        )}

        {/* Recent Results */}
        {recentMatches.length > 0 && (
          <section>
            <SectionHeader title="Recent Results" icon={<CheckCircle className="w-5 h-5 text-green-500" />} href="/matches?status=completed" />
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {recentMatches.slice(0, 6).map(match => (
                <ResultCard key={match.id} match={match} />
              ))}
            </div>
          </section>
        )}

        {/* Stats Section */}
        <section className="grid lg:grid-cols-2 gap-8">
          {/* Top Run Scorers */}
          <div className="cricket-card p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-display text-lg font-bold flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-cricket-orange" /> Top Run Scorers
              </h3>
              <Link href="/leaderboards?tab=runs" className="text-sm text-primary hover:underline">View all</Link>
            </div>
            <div className="space-y-3">
              {topBatsmen.length === 0 ? (
                <p className="text-muted-foreground text-sm">No data yet</p>
              ) : topBatsmen.map((p, i) => (
                <PlayerLeaderboardRow key={p.id} player={p} rank={i + 1} value={p.battingStats.runs} label="runs" />
              ))}
            </div>
          </div>

          {/* Top Wicket Takers */}
          <div className="cricket-card p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-display text-lg font-bold flex items-center gap-2">
                <Award className="w-5 h-5 text-purple-500" /> Top Wicket Takers
              </h3>
              <Link href="/leaderboards?tab=wickets" className="text-sm text-primary hover:underline">View all</Link>
            </div>
            <div className="space-y-3">
              {topBowlers.length === 0 ? (
                <p className="text-muted-foreground text-sm">No data yet</p>
              ) : topBowlers.map((p, i) => (
                <PlayerLeaderboardRow key={p.id} player={p} rank={i + 1} value={p.bowlingStats.wickets} label="wkts" />
              ))}
            </div>
          </div>
        </section>

        {/* Team Rankings */}
        {teams.length > 0 && (
          <section>
            <SectionHeader title="Team Rankings" icon={<Users className="w-5 h-5 text-indigo-500" />} href="/teams" />
            <div className="cricket-card overflow-hidden">
              <table className="w-full">
                <thead>
                  <tr className="border-b bg-muted/50">
                    <th className="text-left px-4 py-3 text-sm font-semibold text-muted-foreground">#</th>
                    <th className="text-left px-4 py-3 text-sm font-semibold text-muted-foreground">Team</th>
                    <th className="text-center px-4 py-3 text-sm font-semibold text-muted-foreground">M</th>
                    <th className="text-center px-4 py-3 text-sm font-semibold text-muted-foreground">W</th>
                    <th className="text-center px-4 py-3 text-sm font-semibold text-muted-foreground">L</th>
                    <th className="text-right px-4 py-3 text-sm font-semibold text-muted-foreground">Win%</th>
                  </tr>
                </thead>
                <tbody>
                  {[...teams].sort((a, b) => b.stats.winPercentage - a.stats.winPercentage).slice(0, 8).map((team, i) => (
                    <tr key={team.id} className="points-table-row">
                      <td className="px-4 py-3 text-sm font-mono text-muted-foreground">{i + 1}</td>
                      <td className="px-4 py-3">
                        <Link href={`/teams/${team.id}`} className="flex items-center gap-3 hover:text-primary transition-colors">
                          {team.logoURL ? (
                            <img src={team.logoURL} alt="" className="w-8 h-8 rounded-full object-cover" />
                          ) : (
                            <div className="w-8 h-8 rounded-full bg-primary/10 text-primary flex items-center justify-center font-bold text-sm">
                              {team.name[0]}
                            </div>
                          )}
                          <span className="font-medium text-sm">{team.name}</span>
                        </Link>
                      </td>
                      <td className="px-4 py-3 text-center text-sm font-mono">{team.stats.matchesPlayed}</td>
                      <td className="px-4 py-3 text-center text-sm font-mono text-green-500 font-semibold">{team.stats.wins}</td>
                      <td className="px-4 py-3 text-center text-sm font-mono text-red-500">{team.stats.losses}</td>
                      <td className="px-4 py-3 text-right text-sm font-mono font-semibold">{team.stats.winPercentage.toFixed(1)}%</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>
        )}

        {/* Empty State */}
        {!loading && liveMatches.length === 0 && upcomingMatches.length === 0 && recentMatches.length === 0 && (
          <div className="text-center py-20">
            <Trophy className="w-16 h-16 text-muted-foreground/30 mx-auto mb-4" />
            <h2 className="font-display text-2xl font-bold text-muted-foreground mb-2">No matches yet</h2>
            <p className="text-muted-foreground mb-6">Create your first match to get started!</p>
            <Link href="/matches/create" className="px-6 py-2.5 rounded-xl bg-primary text-primary-foreground font-medium hover:bg-primary/90 transition-colors">
              Create Match
            </Link>
          </div>
        )}
      </div>
    </div>
  );
}

function SectionHeader({ title, icon, href }: { title: string; icon: React.ReactNode; href: string }) {
  return (
    <div className="flex items-center justify-between mb-4">
      <h2 className="font-display text-xl font-bold flex items-center gap-2">
        {icon} {title}
      </h2>
      <Link href={href} className="flex items-center gap-1 text-sm text-primary hover:underline">
        View all <ChevronRight className="w-4 h-4" />
      </Link>
    </div>
  );
}

function LiveMatchCard({ match }: { match: Match }) {
  return (
    <Link href={`/matches/${match.id}`}>
      <div className="cricket-card p-4 border-red-500/20 bg-gradient-to-br from-red-500/5 to-transparent hover:border-red-500/40 transition-all">
        <div className="flex items-center justify-between mb-3">
          <span className="live-badge">Live</span>
          <span className="text-xs text-muted-foreground">{match.overs} Overs</span>
        </div>
        <div className="space-y-2">
          <TeamScore name={match.teamA.name} summary={match.innings1} />
          <div className="border-t border-dashed border-border/50" />
          <TeamScore name={match.teamB.name} summary={match.innings2} />
        </div>
        {match.ground && (
          <p className="text-xs text-muted-foreground mt-3 truncate">📍 {match.ground}</p>
        )}
      </div>
    </Link>
  );
}

function TeamScore({ name, summary }: { name: string; summary?: Match['innings1'] }) {
  return (
    <div className="flex items-center justify-between">
      <span className="text-sm font-medium truncate max-w-28">{name}</span>
      {summary ? (
        <span className="font-display text-lg font-bold">
          {summary.runs}/{summary.wickets}
          <span className="text-xs text-muted-foreground font-normal ml-1">({summary.overs}.{summary.balls})</span>
        </span>
      ) : (
        <span className="text-sm text-muted-foreground">Yet to bat</span>
      )}
    </div>
  );
}

function UpcomingMatchCard({ match }: { match: Match }) {
  const date = match.date?.toDate?.() || new Date();
  return (
    <Link href={`/matches/${match.id}`}>
      <div className="cricket-card p-4 hover:border-primary/30 transition-all">
        <div className="flex items-center justify-between mb-3">
          <span className="text-xs font-medium text-blue-500 bg-blue-500/10 px-2 py-0.5 rounded-full">Upcoming</span>
          <span className="text-xs text-muted-foreground">{match.overs} Ov</span>
        </div>
        <div className="text-center my-3">
          <p className="font-semibold text-sm">{match.teamA.name}</p>
          <p className="text-xs text-muted-foreground my-1">vs</p>
          <p className="font-semibold text-sm">{match.teamB.name}</p>
        </div>
        <div className="border-t pt-3 flex items-center justify-between text-xs text-muted-foreground">
          <span>📍 {match.ground || 'TBD'}</span>
          <span>{date.toLocaleDateString()}</span>
        </div>
      </div>
    </Link>
  );
}

function ResultCard({ match }: { match: Match }) {
  return (
    <Link href={`/matches/${match.id}`}>
      <div className="cricket-card p-4 hover:border-green-500/30 transition-all">
        <div className="flex items-center justify-between mb-3">
          <span className="text-xs font-medium text-green-500 bg-green-500/10 px-2 py-0.5 rounded-full">Completed</span>
          <span className="text-xs text-muted-foreground">{match.overs} Ov</span>
        </div>
        <div className="space-y-2">
          <TeamScore name={match.teamA.name} summary={match.innings1} />
          <div className="border-t border-dashed border-border/50" />
          <TeamScore name={match.teamB.name} summary={match.innings2} />
        </div>
        {match.result && (
          <div className="mt-3 pt-3 border-t">
            <p className="text-xs font-medium text-primary truncate">{match.result.resultText}</p>
          </div>
        )}
      </div>
    </Link>
  );
}

function PlayerLeaderboardRow({ player, rank, value, label }: { player: Player; rank: number; value: number; label: string }) {
  const medals = ['🥇', '🥈', '🥉'];
  return (
    <Link href={`/players/${player.id}`} className="flex items-center gap-3 hover:bg-muted/50 rounded-lg p-1.5 -mx-1.5 transition-colors">
      <span className="text-lg w-7 text-center">{medals[rank - 1] || <span className="text-sm font-mono text-muted-foreground">{rank}</span>}</span>
      {player.photoURL ? (
        <img src={player.photoURL} alt="" className="w-8 h-8 rounded-full object-cover" />
      ) : (
        <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center text-sm font-bold">
          {player.name[0]}
        </div>
      )}
      <div className="flex-1 min-w-0">
        <p className="text-sm font-medium truncate">{player.name}</p>
        <p className="text-xs text-muted-foreground truncate">{player.teamName || 'No team'}</p>
      </div>
      <div className="text-right">
        <p className="font-display text-lg font-bold">{value}</p>
        <p className="text-xs text-muted-foreground">{label}</p>
      </div>
    </Link>
  );
}
