'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { getAllPlayers, getAllTeams } from '@/lib/services';
import type { Player, Team } from '@/types';
import { TrendingUp, Award, Target, Zap, BarChart3, Users } from 'lucide-react';

type Tab = 'runs' | 'wickets' | 'average' | 'strikeRate' | 'economy' | 'teams';

export default function LeaderboardsPage() {
  const [players, setPlayers] = useState<Player[]>([]);
  const [teams, setTeams] = useState<Team[]>([]);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState<Tab>('runs');

  useEffect(() => {
    Promise.all([getAllPlayers(), getAllTeams()])
      .then(([p, t]) => { setPlayers(p); setTeams(t); })
      .finally(() => setLoading(false));
  }, []);

  const tabs = [
    { key: 'runs' as Tab, label: 'Most Runs', icon: TrendingUp },
    { key: 'wickets' as Tab, label: 'Most Wickets', icon: Target },
    { key: 'average' as Tab, label: 'Batting Avg', icon: BarChart3 },
    { key: 'strikeRate' as Tab, label: 'Strike Rate', icon: Zap },
    { key: 'economy' as Tab, label: 'Economy', icon: Award },
    { key: 'teams' as Tab, label: 'Teams', icon: Users },
  ];

  const getLeaderboardData = (): { player?: Player; team?: Team; value: string; subValue?: string }[] => {
    switch (tab) {
      case 'runs':
        return [...players].filter(p => p.battingStats.innings > 0).sort((a, b) => b.battingStats.runs - a.battingStats.runs).slice(0, 20)
          .map(p => ({ player: p, value: String(p.battingStats.runs), subValue: `${p.battingStats.innings} inns • Avg: ${p.battingStats.average.toFixed(1)}` }));
      case 'wickets':
        return [...players].filter(p => p.bowlingStats.innings > 0).sort((a, b) => b.bowlingStats.wickets - a.bowlingStats.wickets).slice(0, 20)
          .map(p => ({ player: p, value: String(p.bowlingStats.wickets), subValue: `${p.bowlingStats.overs.toFixed(1)} ov • Econ: ${p.bowlingStats.economy.toFixed(1)}` }));
      case 'average':
        return [...players].filter(p => p.battingStats.innings >= 3).sort((a, b) => b.battingStats.average - a.battingStats.average).slice(0, 20)
          .map(p => ({ player: p, value: p.battingStats.average.toFixed(2), subValue: `${p.battingStats.runs} runs` }));
      case 'strikeRate':
        return [...players].filter(p => p.battingStats.innings >= 3).sort((a, b) => b.battingStats.strikeRate - a.battingStats.strikeRate).slice(0, 20)
          .map(p => ({ player: p, value: p.battingStats.strikeRate.toFixed(1), subValue: `${p.battingStats.runs} runs in ${p.battingStats.innings} inns` }));
      case 'economy':
        return [...players].filter(p => p.bowlingStats.overs >= 2).sort((a, b) => a.bowlingStats.economy - b.bowlingStats.economy).slice(0, 20)
          .map(p => ({ player: p, value: p.bowlingStats.economy.toFixed(2), subValue: `${p.bowlingStats.wickets} wkts` }));
      case 'teams':
        return [...teams].filter(t => t.stats.matchesPlayed > 0).sort((a, b) => b.stats.winPercentage - a.stats.winPercentage).slice(0, 20)
          .map(t => ({ team: t, value: `${t.stats.winPercentage.toFixed(1)}%`, subValue: `${t.stats.wins}W ${t.stats.losses}L in ${t.stats.matchesPlayed}M` }));
      default: return [];
    }
  };

  const data = getLeaderboardData();
  const medals = ['🥇', '🥈', '🥉'];

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-8">
      <div className="mb-6">
        <h1 className="font-display text-3xl font-bold">Leaderboards</h1>
        <p className="text-muted-foreground mt-1">Top performers across all matches</p>
      </div>

      {/* Tab Scroll */}
      <div className="flex gap-2 overflow-x-auto pb-2 mb-6 scrollbar-thin">
        {tabs.map(({ key, label, icon: Icon }) => (
          <button key={key} onClick={() => setTab(key)}
            className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-sm font-medium whitespace-nowrap transition-colors shrink-0 ${tab === key ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground hover:text-foreground'}`}>
            <Icon className="w-4 h-4" />{label}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="space-y-3">{Array.from({ length: 10 }).map((_, i) => <div key={i} className="cricket-card h-16 skeleton" />)}</div>
      ) : data.length === 0 ? (
        <div className="text-center py-16 cricket-card text-muted-foreground">
          <BarChart3 className="w-12 h-12 mx-auto mb-4 opacity-30" />
          <p>No data yet. Play some matches first!</p>
        </div>
      ) : (
        <div className="cricket-card overflow-hidden">
          {data.map(({ player, team, value, subValue }, i) => (
            <div key={player?.id || team?.id || i} className={`flex items-center gap-4 px-4 py-3 border-b last:border-0 ${i % 2 === 0 ? '' : 'bg-muted/20'} hover:bg-muted/40 transition-colors`}>
              {/* Rank */}
              <div className="w-8 text-center shrink-0">
                {i < 3 ? (
                  <span className="text-xl">{medals[i]}</span>
                ) : (
                  <span className="text-sm font-mono text-muted-foreground">{i + 1}</span>
                )}
              </div>

              {/* Avatar */}
              {player && (
                player.photoURL ? (
                  <img src={player.photoURL} alt="" className="w-10 h-10 rounded-full object-cover shrink-0" />
                ) : (
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-primary/20 to-muted flex items-center justify-center font-bold text-primary shrink-0">
                    {player.name[0]}
                  </div>
                )
              )}
              {team && (
                team.logoURL ? (
                  <img src={team.logoURL} alt="" className="w-10 h-10 rounded-full object-cover shrink-0" />
                ) : (
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-primary/20 to-muted flex items-center justify-center font-bold text-primary shrink-0">
                    {team.name[0]}
                  </div>
                )
              )}

              {/* Info */}
              <div className="flex-1 min-w-0">
                {player && (
                  <Link href={`/players/${player.id}`} className="font-semibold hover:text-primary transition-colors block truncate">{player.name}</Link>
                )}
                {team && (
                  <Link href={`/teams/${team.id}`} className="font-semibold hover:text-primary transition-colors block truncate">{team.name}</Link>
                )}
                {subValue && <p className="text-xs text-muted-foreground truncate">{subValue}</p>}
              </div>

              {/* Value */}
              <div className="text-right shrink-0">
                <p className={`font-display text-2xl font-bold ${i === 0 ? 'text-cricket-gold' : i === 1 ? 'text-slate-400' : i === 2 ? 'text-amber-600' : 'text-foreground'}`}>
                  {value}
                </p>
                <p className="text-xs text-muted-foreground">
                  {tab === 'runs' ? 'runs' : tab === 'wickets' ? 'wkts' : tab === 'average' ? 'avg' : tab === 'strikeRate' ? 'SR' : tab === 'economy' ? 'econ' : 'win%'}
                </p>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
