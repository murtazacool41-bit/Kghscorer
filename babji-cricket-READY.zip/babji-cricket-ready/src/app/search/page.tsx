'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { getAllPlayers, getAllTeams, getAllMatches, getAllTournaments } from '@/lib/services';
import type { Player, Team, Match, Tournament } from '@/types';
import { Search, User, Users, Calendar, Trophy } from 'lucide-react';

type ResultType = 'player' | 'team' | 'match' | 'tournament';
interface SearchResult { type: ResultType; id: string; title: string; subtitle: string; href: string; }

export default function SearchPage() {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<SearchResult[]>([]);
  const [all, setAll] = useState<{ players: Player[]; teams: Team[]; matches: Match[]; tournaments: Tournament[] }>({ players: [], teams: [], matches: [], tournaments: [] });
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<ResultType | 'all'>('all');

  useEffect(() => {
    Promise.all([getAllPlayers(), getAllTeams(), getAllMatches(), getAllTournaments()])
      .then(([players, teams, matches, tournaments]) => setAll({ players, teams, matches, tournaments }))
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    if (!query.trim()) { setResults([]); return; }
    const q = query.toLowerCase();
    const r: SearchResult[] = [];

    all.players.filter(p => p.name.toLowerCase().includes(q)).forEach(p =>
      r.push({ type: 'player', id: p.id, title: p.name, subtitle: `${p.role} • ${p.teamName || 'No team'} • ${p.battingStats.runs} runs`, href: `/players/${p.id}` })
    );
    all.teams.filter(t => t.name.toLowerCase().includes(q) || t.captainName.toLowerCase().includes(q)).forEach(t =>
      r.push({ type: 'team', id: t.id, title: t.name, subtitle: `Captain: ${t.captainName} • ${t.stats.matchesPlayed} matches`, href: `/teams/${t.id}` })
    );
    all.matches.filter(m => m.teamA.name.toLowerCase().includes(q) || m.teamB.name.toLowerCase().includes(q) || m.ground?.toLowerCase().includes(q)).forEach(m =>
      r.push({ type: 'match', id: m.id, title: `${m.teamA.name} vs ${m.teamB.name}`, subtitle: `${m.ground} • ${m.status}`, href: `/matches/${m.id}` })
    );
    all.tournaments.filter(t => t.name.toLowerCase().includes(q)).forEach(t =>
      r.push({ type: 'tournament', id: t.id, title: t.name, subtitle: `${t.format} • ${t.teamIds?.length || 0} teams`, href: `/tournaments/${t.id}` })
    );

    setResults(r);
  }, [query, all]);

  const typeIcon = (type: ResultType) => {
    if (type === 'player') return <User className="w-4 h-4" />;
    if (type === 'team') return <Users className="w-4 h-4" />;
    if (type === 'match') return <Calendar className="w-4 h-4" />;
    return <Trophy className="w-4 h-4" />;
  };

  const typeColor = (type: ResultType) => {
    if (type === 'player') return 'text-blue-500 bg-blue-500/10';
    if (type === 'team') return 'text-green-500 bg-green-500/10';
    if (type === 'match') return 'text-orange-500 bg-orange-500/10';
    return 'text-cricket-gold bg-cricket-gold/10';
  };

  const filtered = filter === 'all' ? results : results.filter(r => r.type === filter);
  const counts = { player: results.filter(r => r.type === 'player').length, team: results.filter(r => r.type === 'team').length, match: results.filter(r => r.type === 'match').length, tournament: results.filter(r => r.type === 'tournament').length };

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 py-8">
      <h1 className="font-display text-3xl font-bold mb-6">Search</h1>

      {/* Search Input */}
      <div className="relative mb-4">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
        <input
          autoFocus
          value={query}
          onChange={e => setQuery(e.target.value)}
          placeholder="Search players, teams, matches, tournaments..."
          className="w-full pl-12 pr-4 py-3.5 rounded-2xl border border-input bg-background text-base focus:outline-none focus:ring-2 focus:ring-ring shadow-sm"
        />
      </div>

      {/* Filters */}
      {query && results.length > 0 && (
        <div className="flex gap-2 mb-4 flex-wrap">
          {(['all', 'player', 'team', 'match', 'tournament'] as const).map(f => (
            <button key={f} onClick={() => setFilter(f)}
              className={`px-3 py-1 rounded-lg text-sm font-medium transition-colors capitalize ${filter === f ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground hover:text-foreground'}`}>
              {f}{f !== 'all' && counts[f] > 0 ? ` (${counts[f]})` : ''}
            </button>
          ))}
        </div>
      )}

      {/* Results */}
      {loading ? (
        <p className="text-center text-muted-foreground py-8">Loading search index...</p>
      ) : !query ? (
        <div className="text-center py-16">
          <Search className="w-12 h-12 text-muted-foreground/20 mx-auto mb-4" />
          <p className="text-muted-foreground">Type to search across everything</p>
          <div className="flex justify-center gap-3 mt-4 flex-wrap text-sm text-muted-foreground">
            {[`${all.players.length} players`, `${all.teams.length} teams`, `${all.matches.length} matches`, `${all.tournaments.length} tournaments`].map(s => (
              <span key={s} className="px-2 py-1 rounded-lg bg-muted">{s}</span>
            ))}
          </div>
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-16">
          <p className="text-muted-foreground">No results for "<strong>{query}</strong>"</p>
        </div>
      ) : (
        <div className="space-y-2">
          {filtered.map(result => (
            <Link key={`${result.type}-${result.id}`} href={result.href}>
              <div className="cricket-card p-4 flex items-center gap-4 hover:border-primary/30 transition-all">
                <div className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${typeColor(result.type)}`}>
                  {typeIcon(result.type)}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-semibold truncate">{result.title}</p>
                  <p className="text-xs text-muted-foreground truncate">{result.subtitle}</p>
                </div>
                <span className={`text-xs font-medium px-2 py-0.5 rounded-full capitalize shrink-0 ${typeColor(result.type)}`}>{result.type}</span>
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
