'use client';
import { useEffect, useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import Link from 'next/link';
import { getTeam, getPlayersByTeam, createPlayer, uploadPlayerPhoto, deleteTeam } from '@/lib/services';
import { useAuth } from '@/lib/auth-context';
import type { Team, Player, BattingStyle, BowlingStyle, PlayerRole } from '@/types';
import toast from 'react-hot-toast';
import { Users, Plus, Trash2, ArrowLeft, Star, Activity, Target, X, Upload } from 'lucide-react';

export default function TeamDetailPage() {
  const { id } = useParams<{ id: string }>();
  const [team, setTeam] = useState<Team | null>(null);
  const [players, setPlayers] = useState<Player[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAddPlayer, setShowAddPlayer] = useState(false);
  const [tab, setTab] = useState<'players' | 'stats'>('players');
  const { user, isAdmin, isScorer } = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (!id) return;
    Promise.all([getTeam(id), getPlayersByTeam(id)])
      .then(([t, p]) => { setTeam(t); setPlayers(p); })
      .finally(() => setLoading(false));
  }, [id]);

  const handleDelete = async () => {
    if (!confirm('Delete this team?')) return;
    await deleteTeam(id);
    router.push('/teams');
    toast.success('Team deleted');
  };

  if (loading) return <div className="max-w-4xl mx-auto px-4 py-12 text-center"><p className="text-muted-foreground">Loading...</p></div>;
  if (!team) return <div className="max-w-4xl mx-auto px-4 py-12 text-center"><p>Team not found</p></div>;

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-8">
      <Link href="/teams" className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground mb-6 transition-colors">
        <ArrowLeft className="w-4 h-4" /> All Teams
      </Link>

      {/* Header */}
      <div className="cricket-card p-6 mb-6">
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-6">
          {team.logoURL ? (
            <img src={team.logoURL} alt={team.name} className="w-20 h-20 rounded-2xl object-cover ring-2 ring-border" />
          ) : (
            <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-primary/30 to-primary/5 flex items-center justify-center ring-2 ring-border">
              <span className="font-display text-3xl font-bold text-primary">{team.name[0]}</span>
            </div>
          )}
          <div className="flex-1">
            <h1 className="font-display text-3xl font-bold">{team.name}</h1>
            <p className="text-muted-foreground">Captain: <span className="font-medium text-foreground">{team.captainName}</span></p>
            {team.description && <p className="text-sm text-muted-foreground mt-2">{team.description}</p>}
          </div>
          {isAdmin && (
            <button onClick={handleDelete} className="p-2 rounded-lg text-destructive hover:bg-destructive/10 transition-colors">
              <Trash2 className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Stats bar */}
        <div className="grid grid-cols-4 sm:grid-cols-5 gap-4 mt-6 pt-6 border-t">
          <StatBox label="Matches" value={team.stats.matchesPlayed} />
          <StatBox label="Wins" value={team.stats.wins} color="text-green-500" />
          <StatBox label="Losses" value={team.stats.losses} color="text-red-500" />
          <StatBox label="Ties" value={team.stats.ties} />
          <StatBox label="Win %" value={`${team.stats.winPercentage.toFixed(1)}%`} color="text-primary" className="hidden sm:block" />
        </div>
      </div>

      {/* Tabs */}
      <div className="flex rounded-xl bg-muted p-1 mb-6 max-w-xs">
        {(['players', 'stats'] as const).map(t => (
          <button key={t} onClick={() => setTab(t)} className={`flex-1 py-2 text-sm font-medium rounded-lg transition-all capitalize ${tab === t ? 'bg-background shadow text-foreground' : 'text-muted-foreground'}`}>
            {t}
          </button>
        ))}
      </div>

      {tab === 'players' && (
        <div>
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-display text-lg font-bold flex items-center gap-2">
              <Users className="w-5 h-5" /> Players ({players.length})
            </h2>
            {(isAdmin || isScorer) && (
              <button onClick={() => setShowAddPlayer(true)} className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 transition-colors">
                <Plus className="w-4 h-4" /> Add Player
              </button>
            )}
          </div>

          {players.length === 0 ? (
            <div className="text-center py-12 cricket-card">
              <Users className="w-10 h-10 text-muted-foreground/30 mx-auto mb-3" />
              <p className="text-muted-foreground">No players yet. Add your squad!</p>
            </div>
          ) : (
            <div className="grid sm:grid-cols-2 gap-3">
              {players.map(player => <PlayerCard key={player.id} player={player} />)}
            </div>
          )}
        </div>
      )}

      {tab === 'stats' && (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          <DetailStat icon={<Activity className="w-5 h-5 text-blue-500" />} label="Total Matches" value={team.stats.matchesPlayed} />
          <DetailStat icon={<Star className="w-5 h-5 text-green-500" />} label="Wins" value={team.stats.wins} />
          <DetailStat icon={<Target className="w-5 h-5 text-red-500" />} label="Losses" value={team.stats.losses} />
          <DetailStat icon={<Activity className="w-5 h-5 text-amber-500" />} label="Ties" value={team.stats.ties} />
          <DetailStat icon={<Star className="w-5 h-5 text-primary" />} label="Win Percentage" value={`${team.stats.winPercentage.toFixed(2)}%`} />
          <DetailStat icon={<Activity className="w-5 h-5 text-purple-500" />} label="Total Players" value={players.length} />
        </div>
      )}

      {showAddPlayer && (
        <AddPlayerModal
          teamId={id}
          teamName={team.name}
          userId={user!.id}
          onClose={() => setShowAddPlayer(false)}
          onAdded={(p) => { setPlayers(prev => [...prev, p]); setShowAddPlayer(false); }}
        />
      )}
    </div>
  );
}

function StatBox({ label, value, color = '', className = '' }: { label: string; value: number | string; color?: string; className?: string }) {
  return (
    <div className={`text-center ${className}`}>
      <p className={`font-display text-2xl font-bold ${color}`}>{value}</p>
      <p className="text-xs text-muted-foreground">{label}</p>
    </div>
  );
}

function DetailStat({ icon, label, value }: { icon: React.ReactNode; label: string; value: number | string }) {
  return (
    <div className="cricket-card p-4 flex items-center gap-4">
      <div className="w-10 h-10 rounded-xl bg-muted flex items-center justify-center shrink-0">{icon}</div>
      <div>
        <p className="font-display text-xl font-bold">{value}</p>
        <p className="text-sm text-muted-foreground">{label}</p>
      </div>
    </div>
  );
}

function PlayerCard({ player }: { player: Player }) {
  return (
    <Link href={`/players/${player.id}`}>
      <div className="cricket-card p-4 flex items-center gap-4 hover:border-primary/30 transition-all">
        {player.photoURL ? (
          <img src={player.photoURL} alt={player.name} className="w-12 h-12 rounded-full object-cover" />
        ) : (
          <div className="w-12 h-12 rounded-full bg-muted flex items-center justify-center font-bold text-lg">
            {player.name[0]}
          </div>
        )}
        <div className="flex-1 min-w-0">
          <p className="font-semibold truncate">{player.name}</p>
          <p className="text-xs text-muted-foreground">{player.role} • {player.battingStyle}</p>
        </div>
        <div className="text-right text-xs text-muted-foreground">
          <p className="font-mono font-semibold text-foreground">{player.battingStats.runs} runs</p>
          <p>{player.bowlingStats.wickets} wkts</p>
        </div>
      </div>
    </Link>
  );
}

function AddPlayerModal({ teamId, teamName, userId, onClose, onAdded }: {
  teamId: string; teamName: string; userId: string;
  onClose: () => void; onAdded: (p: Player) => void;
}) {
  const [name, setName] = useState('');
  const [battingStyle, setBattingStyle] = useState<BattingStyle>('Right Handed');
  const [bowlingStyle, setBowlingStyle] = useState<BowlingStyle>('Right Arm Fast');
  const [role, setRole] = useState<PlayerRole>('Batsman');
  const [photoFile, setPhotoFile] = useState<File | null>(null);
  const [photoPreview, setPhotoPreview] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const id = await createPlayer({ name, battingStyle, bowlingStyle, role, teamId, teamName, createdBy: userId });
      let photoURL: string | undefined;
      if (photoFile) {
        photoURL = await uploadPlayerPhoto(id, photoFile);
        const { updatePlayer } = await import('@/lib/services');
        await updatePlayer(id, { photoURL });
      }
      const newPlayer: Player = {
        id, name, battingStyle, bowlingStyle, role, teamId, teamName, photoURL,
        createdBy: userId, createdAt: new Date() as any,
        battingStats: { matches: 0, innings: 0, runs: 0, highestScore: 0, highestScoreNotOut: false, notOuts: 0, average: 0, strikeRate: 0, fours: 0, sixes: 0, fifties: 0, hundreds: 0, ducks: 0 },
        bowlingStats: { matches: 0, innings: 0, overs: 0, balls: 0, maidens: 0, runs: 0, wickets: 0, bestBowlingWickets: 0, bestBowlingRuns: 999, average: 0, economy: 0, strikeRate: 0, fourWickets: 0, fiveWickets: 0 },
        fieldingStats: { catches: 0, runOuts: 0, stumpings: 0 },
      };
      onAdded(newPlayer);
      toast.success('Player added!');
    } catch (err: any) {
      toast.error(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
      <div className="w-full max-w-md cricket-card p-6 max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-display text-xl font-bold">Add Player</h2>
          <button onClick={onClose} className="p-1 rounded-lg hover:bg-muted"><X className="w-5 h-5" /></button>
        </div>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="flex flex-col items-center gap-2">
            {photoPreview ? (
              <img src={photoPreview} alt="" className="w-16 h-16 rounded-full object-cover ring-2 ring-primary" />
            ) : (
              <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center text-2xl font-bold">?</div>
            )}
            <label className="cursor-pointer text-sm text-primary hover:underline flex items-center gap-1">
              <Upload className="w-4 h-4" /> Photo
              <input type="file" accept="image/*" onChange={e => { const f = e.target.files?.[0]; if (f) { setPhotoFile(f); setPhotoPreview(URL.createObjectURL(f)); }}} className="sr-only" />
            </label>
          </div>

          <div>
            <label className="block text-sm font-medium mb-1">Name *</label>
            <input value={name} onChange={e => setName(e.target.value)} required className="w-full px-3 py-2 rounded-xl border border-input bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring" />
          </div>

          <div>
            <label className="block text-sm font-medium mb-1">Role</label>
            <select value={role} onChange={e => setRole(e.target.value as PlayerRole)} className="w-full px-3 py-2 rounded-xl border border-input bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring">
              {['Batsman', 'Bowler', 'All Rounder', 'Wicket Keeper'].map(r => <option key={r}>{r}</option>)}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium mb-1">Batting Style</label>
            <select value={battingStyle} onChange={e => setBattingStyle(e.target.value as BattingStyle)} className="w-full px-3 py-2 rounded-xl border border-input bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring">
              <option>Right Handed</option><option>Left Handed</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium mb-1">Bowling Style</label>
            <select value={bowlingStyle} onChange={e => setBowlingStyle(e.target.value as BowlingStyle)} className="w-full px-3 py-2 rounded-xl border border-input bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring">
              {['Right Arm Fast', 'Right Arm Medium', 'Right Arm Off Spin', 'Right Arm Leg Spin', 'Left Arm Fast', 'Left Arm Medium', 'Left Arm Orthodox', 'Left Arm Chinaman'].map(s => <option key={s}>{s}</option>)}
            </select>
          </div>

          <div className="flex gap-3 pt-2">
            <button type="button" onClick={onClose} className="flex-1 py-2 rounded-xl border text-sm font-medium hover:bg-muted">Cancel</button>
            <button type="submit" disabled={loading} className="flex-1 py-2 rounded-xl bg-primary text-primary-foreground text-sm font-medium disabled:opacity-50">
              {loading ? 'Adding...' : 'Add Player'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
