'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { getAllTeams, createTeam, uploadTeamLogo } from '@/lib/services';
import { useAuth } from '@/lib/auth-context';
import type { Team } from '@/types';
import toast from 'react-hot-toast';
import { Plus, Users, Trophy, TrendingUp, Search, Upload, X } from 'lucide-react';

export default function TeamsPage() {
  const [teams, setTeams] = useState<Team[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [showCreate, setShowCreate] = useState(false);
  const { user, isAdmin, isScorer } = useAuth();

  useEffect(() => {
    getAllTeams().then(setTeams).finally(() => setLoading(false));
  }, []);

  const filtered = teams.filter(t => t.name.toLowerCase().includes(search.toLowerCase()));

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="font-display text-3xl font-bold">Teams</h1>
          <p className="text-muted-foreground mt-1">{teams.length} team{teams.length !== 1 ? 's' : ''} registered</p>
        </div>
        {(isAdmin || isScorer) && (
          <button
            onClick={() => setShowCreate(true)}
            className="flex items-center gap-2 px-4 py-2 rounded-xl bg-primary text-primary-foreground font-medium text-sm hover:bg-primary/90 transition-colors"
          >
            <Plus className="w-4 h-4" /> Create Team
          </button>
        )}
      </div>

      {/* Search */}
      <div className="relative mb-6">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <input
          value={search}
          onChange={e => setSearch(e.target.value)}
          placeholder="Search teams..."
          className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-input bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring max-w-md"
        />
      </div>

      {loading ? (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {Array.from({ length: 8 }).map((_, i) => (
            <div key={i} className="cricket-card p-6 space-y-3">
              <div className="skeleton w-16 h-16 rounded-full mx-auto" />
              <div className="skeleton h-4 rounded w-3/4 mx-auto" />
              <div className="skeleton h-3 rounded w-1/2 mx-auto" />
            </div>
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-16">
          <Users className="w-12 h-12 text-muted-foreground/30 mx-auto mb-4" />
          <p className="text-muted-foreground">No teams found</p>
        </div>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {filtered.map(team => <TeamCard key={team.id} team={team} />)}
        </div>
      )}

      {showCreate && (
        <CreateTeamModal
          onClose={() => setShowCreate(false)}
          onCreated={(t) => { setTeams(prev => [...prev, t]); setShowCreate(false); }}
          userId={user!.id}
        />
      )}
    </div>
  );
}

function TeamCard({ team }: { team: Team }) {
  return (
    <Link href={`/teams/${team.id}`}>
      <div className="cricket-card p-6 text-center hover:border-primary/30 hover:shadow-md transition-all">
        {team.logoURL ? (
          <img src={team.logoURL} alt={team.name} className="w-16 h-16 rounded-full object-cover mx-auto mb-3 ring-2 ring-border" />
        ) : (
          <div className="w-16 h-16 rounded-full bg-gradient-to-br from-primary/20 to-primary/5 flex items-center justify-center mx-auto mb-3 ring-2 ring-border">
            <span className="font-display text-2xl font-bold text-primary">{team.name[0]}</span>
          </div>
        )}
        <h3 className="font-display font-bold text-lg mb-1 truncate">{team.name}</h3>
        <p className="text-xs text-muted-foreground mb-3">Captain: {team.captainName}</p>

        <div className="grid grid-cols-3 gap-2 text-center border-t pt-3">
          <Stat label="M" value={team.stats.matchesPlayed} />
          <Stat label="W" value={team.stats.wins} highlight />
          <Stat label="L" value={team.stats.losses} danger />
        </div>
      </div>
    </Link>
  );
}

function Stat({ label, value, highlight, danger }: { label: string; value: number; highlight?: boolean; danger?: boolean }) {
  return (
    <div>
      <p className={`font-display font-bold text-lg ${highlight ? 'text-green-500' : danger ? 'text-red-500' : ''}`}>{value}</p>
      <p className="text-xs text-muted-foreground">{label}</p>
    </div>
  );
}

function CreateTeamModal({ onClose, onCreated, userId }: { onClose: () => void; onCreated: (t: Team) => void; userId: string }) {
  const [name, setName] = useState('');
  const [captainName, setCaptainName] = useState('');
  const [description, setDescription] = useState('');
  const [logoFile, setLogoFile] = useState<File | null>(null);
  const [logoPreview, setLogoPreview] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleLogo = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setLogoFile(file);
      setLogoPreview(URL.createObjectURL(file));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const id = await createTeam({
        name, captainName, captainId: userId, description,
        playerIds: [], createdBy: userId, logoURL: undefined as any,
      });
      let logoURL: string | undefined;
      if (logoFile) {
        logoURL = await uploadTeamLogo(id, logoFile);
        const { updateTeam } = await import('@/lib/services');
        await updateTeam(id, { logoURL });
      }
      const newTeam: Team = {
        id, name, captainName, captainId: userId, description,
        playerIds: [], createdBy: userId, logoURL,
        createdAt: new Date() as any,
        stats: { matchesPlayed: 0, wins: 0, losses: 0, ties: 0, noResult: 0, winPercentage: 0, runsScored: 0, wicketsTaken: 0 }
      };
      onCreated(newTeam);
      toast.success('Team created!');
    } catch (err: any) {
      toast.error(err.message || 'Failed to create team');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
      <div className="w-full max-w-md cricket-card p-6 max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-display text-xl font-bold">Create Team</h2>
          <button onClick={onClose} className="p-1 rounded-lg hover:bg-muted transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Logo Upload */}
          <div className="flex flex-col items-center gap-3">
            {logoPreview ? (
              <img src={logoPreview} alt="" className="w-20 h-20 rounded-full object-cover ring-2 ring-primary" />
            ) : (
              <div className="w-20 h-20 rounded-full bg-muted flex items-center justify-center">
                <Users className="w-8 h-8 text-muted-foreground" />
              </div>
            )}
            <label className="cursor-pointer flex items-center gap-2 text-sm text-primary hover:underline">
              <Upload className="w-4 h-4" /> Upload Logo
              <input type="file" accept="image/*" onChange={handleLogo} className="sr-only" />
            </label>
          </div>

          <div>
            <label className="block text-sm font-medium mb-1.5">Team Name *</label>
            <input value={name} onChange={e => setName(e.target.value)} required placeholder="Mumbai Tigers" className="w-full px-3 py-2.5 rounded-xl border border-input bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring" />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1.5">Captain Name *</label>
            <input value={captainName} onChange={e => setCaptainName(e.target.value)} required placeholder="Rohit Sharma" className="w-full px-3 py-2.5 rounded-xl border border-input bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring" />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1.5">Description</label>
            <textarea value={description} onChange={e => setDescription(e.target.value)} rows={3} placeholder="About your team..." className="w-full px-3 py-2.5 rounded-xl border border-input bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring resize-none" />
          </div>

          <div className="flex gap-3 pt-2">
            <button type="button" onClick={onClose} className="flex-1 py-2.5 rounded-xl border border-border text-sm font-medium hover:bg-muted transition-colors">Cancel</button>
            <button type="submit" disabled={loading} className="flex-1 py-2.5 rounded-xl bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 transition-colors disabled:opacity-50">
              {loading ? 'Creating...' : 'Create Team'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
