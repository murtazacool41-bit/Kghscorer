'use client';
import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { getAllUsers, getAllTeams, getAllMatches, getAllTournaments, getAllPlayers, setUserRole } from '@/lib/services';
import { useAuth } from '@/lib/auth-context';
import type { User, Team, Match, Tournament, Player } from '@/types';
import toast from 'react-hot-toast';
import { Shield, Users, Calendar, Trophy, User as UserIcon, BarChart3, CheckCircle, AlertTriangle } from 'lucide-react';

export default function AdminPage() {
  const { isAdmin, loading: authLoading } = useAuth();
  const router = useRouter();
  const [users, setUsers] = useState<User[]>([]);
  const [teams, setTeams] = useState<Team[]>([]);
  const [matches, setMatches] = useState<Match[]>([]);
  const [tournaments, setTournaments] = useState<Tournament[]>([]);
  const [players, setPlayers] = useState<Player[]>([]);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState<'overview' | 'users'>('overview');

  useEffect(() => {
    if (!authLoading && !isAdmin) { router.push('/'); return; }
    if (isAdmin) {
      Promise.all([getAllUsers(), getAllTeams(), getAllMatches(), getAllTournaments(), getAllPlayers()])
        .then(([u, t, m, to, p]) => { setUsers(u); setTeams(t); setMatches(m); setTournaments(to); setPlayers(p); })
        .finally(() => setLoading(false));
    }
  }, [isAdmin, authLoading]);

  const handleRoleChange = async (userId: string, role: string) => {
    await setUserRole(userId, role);
    setUsers(prev => prev.map(u => u.id === userId ? { ...u, role: role as User['role'] } : u));
    toast.success('Role updated');
  };

  if (authLoading || loading) return <div className="max-w-6xl mx-auto px-4 py-12 text-center text-muted-foreground">Loading admin panel...</div>;
  if (!isAdmin) return null;

  const liveMatches = matches.filter(m => m.status === 'live').length;
  const completedMatches = matches.filter(m => m.status === 'completed').length;

  const stats = [
    { label: 'Total Users', value: users.length, icon: Users, color: 'text-blue-500', bg: 'bg-blue-500/10' },
    { label: 'Teams', value: teams.length, icon: Shield, color: 'text-green-500', bg: 'bg-green-500/10' },
    { label: 'Players', value: players.length, icon: UserIcon, color: 'text-purple-500', bg: 'bg-purple-500/10' },
    { label: 'Total Matches', value: matches.length, icon: Calendar, color: 'text-orange-500', bg: 'bg-orange-500/10' },
    { label: 'Live Now', value: liveMatches, icon: AlertTriangle, color: 'text-red-500', bg: 'bg-red-500/10' },
    { label: 'Completed', value: completedMatches, icon: CheckCircle, color: 'text-cricket-green', bg: 'bg-cricket-green/10' },
    { label: 'Tournaments', value: tournaments.length, icon: Trophy, color: 'text-cricket-gold', bg: 'bg-cricket-gold/10' },
    { label: 'Avg per Team', value: teams.length > 0 ? (players.length / teams.length).toFixed(1) : 0, icon: BarChart3, color: 'text-indigo-500', bg: 'bg-indigo-500/10' },
  ];

  const roleColors = { admin: 'text-red-500 bg-red-500/10', scorer: 'text-blue-500 bg-blue-500/10', user: 'text-muted-foreground bg-muted' };

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-8">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-10 h-10 rounded-xl bg-red-500/10 flex items-center justify-center">
          <Shield className="w-5 h-5 text-red-500" />
        </div>
        <div>
          <h1 className="font-display text-3xl font-bold">Admin Dashboard</h1>
          <p className="text-muted-foreground text-sm">Manage your cricket platform</p>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex rounded-xl bg-muted p-1 mb-6 max-w-xs">
        {(['overview', 'users'] as const).map(t => (
          <button key={t} onClick={() => setTab(t)} className={`flex-1 py-2 text-sm font-medium rounded-lg transition-all capitalize ${tab === t ? 'bg-background shadow text-foreground' : 'text-muted-foreground'}`}>{t}</button>
        ))}
      </div>

      {tab === 'overview' && (
        <>
          {/* Stats Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-8">
            {stats.map(({ label, value, icon: Icon, color, bg }) => (
              <div key={label} className="cricket-card p-4">
                <div className={`w-10 h-10 rounded-xl ${bg} flex items-center justify-center mb-3`}>
                  <Icon className={`w-5 h-5 ${color}`} />
                </div>
                <p className="font-display text-2xl font-bold">{value}</p>
                <p className="text-sm text-muted-foreground">{label}</p>
              </div>
            ))}
          </div>

          {/* Recent Matches */}
          <div className="cricket-card overflow-hidden mb-6">
            <div className="px-4 py-3 border-b bg-muted/30">
              <h2 className="font-display font-bold">Recent Matches</h2>
            </div>
            <div className="divide-y">
              {matches.slice(0, 8).map(m => (
                <div key={m.id} className="flex items-center justify-between px-4 py-3 hover:bg-muted/30 transition-colors">
                  <div>
                    <p className="text-sm font-medium">{m.teamA.name} vs {m.teamB.name}</p>
                    <p className="text-xs text-muted-foreground">{m.ground} • {m.date?.toDate?.()?.toLocaleDateString()}</p>
                  </div>
                  <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${m.status === 'live' ? 'text-red-500 bg-red-500/10' : m.status === 'completed' ? 'text-green-500 bg-green-500/10' : 'text-blue-500 bg-blue-500/10'}`}>
                    {m.status}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Quick Links */}
          <div className="grid sm:grid-cols-3 gap-3">
            {[
              { href: '/matches/create', label: 'Create Match', icon: Calendar, color: 'text-orange-500' },
              { href: '/teams', label: 'Manage Teams', icon: Users, color: 'text-green-500' },
              { href: '/tournaments', label: 'Tournaments', icon: Trophy, color: 'text-cricket-gold' },
            ].map(({ href, label, icon: Icon, color }) => (
              <a key={href} href={href} className="cricket-card p-4 flex items-center gap-3 hover:border-primary/30 transition-all">
                <Icon className={`w-5 h-5 ${color}`} />
                <span className="font-medium text-sm">{label}</span>
              </a>
            ))}
          </div>
        </>
      )}

      {tab === 'users' && (
        <div className="cricket-card overflow-hidden">
          <div className="px-4 py-3 border-b bg-muted/30">
            <h2 className="font-display font-bold">All Users ({users.length})</h2>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full min-w-[500px]">
              <thead>
                <tr className="text-xs text-muted-foreground border-b bg-muted/20">
                  <th className="text-left px-4 py-2">User</th>
                  <th className="text-left px-4 py-2">Email</th>
                  <th className="text-center px-3 py-2">Role</th>
                  <th className="text-right px-4 py-2">Change Role</th>
                </tr>
              </thead>
              <tbody>
                {users.map((u, i) => (
                  <tr key={u.id} className={`border-b last:border-0 ${i % 2 === 0 ? '' : 'bg-muted/10'}`}>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2">
                        {u.photoURL ? (
                          <img src={u.photoURL} alt="" className="w-8 h-8 rounded-full object-cover" />
                        ) : (
                          <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center font-bold text-sm">{u.displayName?.[0]}</div>
                        )}
                        <span className="text-sm font-medium">{u.displayName}</span>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-sm text-muted-foreground">{u.email}</td>
                    <td className="px-3 py-3 text-center">
                      <span className={`text-xs font-medium px-2 py-0.5 rounded-full capitalize ${roleColors[u.role] || roleColors.user}`}>{u.role}</span>
                    </td>
                    <td className="px-4 py-3 text-right">
                      <select
                        value={u.role}
                        onChange={e => handleRoleChange(u.id, e.target.value)}
                        className="px-2 py-1 rounded-lg border border-input bg-background text-xs focus:outline-none"
                      >
                        <option value="user">User</option>
                        <option value="scorer">Scorer</option>
                        <option value="admin">Admin</option>
                      </select>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
