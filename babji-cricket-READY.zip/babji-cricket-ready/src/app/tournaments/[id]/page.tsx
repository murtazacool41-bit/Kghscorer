'use client';
import { useEffect, useState } from 'react';
import { useParams } from 'next/navigation';
import Link from 'next/link';
import { getTournament, getTournamentPointsTable, getAllTeams, addTeamToTournament, getAllMatches, updateTournament } from '@/lib/services';
import { useAuth } from '@/lib/auth-context';
import type { Tournament, PointsTableEntry, Team, Match } from '@/types';
import toast from 'react-hot-toast';
import { ArrowLeft, Trophy, Plus, Users, Calendar } from 'lucide-react';

export default function TournamentDetailPage() {
  const { id } = useParams<{ id: string }>();
  const [tournament, setTournament] = useState<Tournament | null>(null);
  const [pointsTable, setPointsTable] = useState<PointsTableEntry[]>([]);
  const [allTeams, setAllTeams] = useState<Team[]>([]);
  const [matches, setMatches] = useState<Match[]>([]);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState<'table' | 'fixtures' | 'teams'>('table');
  const [showAddTeam, setShowAddTeam] = useState(false);
  const { isAdmin, isScorer } = useAuth();

  useEffect(() => {
    if (!id) return;
    Promise.all([
      getTournament(id),
      getTournamentPointsTable(id),
      getAllTeams(),
      getAllMatches(),
    ]).then(([t, pt, teams, m]) => {
      setTournament(t);
      setPointsTable(pt);
      setAllTeams(teams);
      setMatches(m.filter(match => match.tournamentId === id));
    }).finally(() => setLoading(false));
  }, [id]);

  const handleAddTeam = async (teamId: string) => {
    if (!tournament) return;
    if (tournament.teamIds.includes(teamId)) { toast.error('Team already in tournament'); return; }
    await addTeamToTournament(id, teamId);
    const team = allTeams.find(t => t.id === teamId)!;
    setTournament(prev => prev ? { ...prev, teamIds: [...prev.teamIds, teamId] } : prev);
    const newEntry: PointsTableEntry = {
      id: '', tournamentId: id, teamId, teamName: team.name, teamLogoURL: team.logoURL,
      matchesPlayed: 0, wins: 0, losses: 0, ties: 0, noResult: 0,
      points: 0, runsScored: 0, runsConceded: 0, oversFaced: 0, oversBowled: 0, netRunRate: 0,
    };
    setPointsTable(prev => [...prev, newEntry]);
    toast.success(`${team.name} added!`);
    setShowAddTeam(false);
  };

  const handleStatusChange = async (status: Tournament['status']) => {
    await updateTournament(id, { status });
    setTournament(prev => prev ? { ...prev, status } : prev);
    toast.success(`Status updated to ${status}`);
  };

  if (loading) return <div className="max-w-4xl mx-auto px-4 py-12 text-center text-muted-foreground">Loading...</div>;
  if (!tournament) return <div className="max-w-4xl mx-auto px-4 py-12 text-center">Tournament not found</div>;

  const availableTeams = allTeams.filter(t => !tournament.teamIds.includes(t.id));

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-8">
      <Link href="/tournaments" className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground mb-6">
        <ArrowLeft className="w-4 h-4" /> Tournaments
      </Link>

      {/* Header */}
      <div className="cricket-card p-6 mb-6 bg-gradient-to-br from-cricket-gold/5 to-transparent">
        <div className="flex items-start gap-4">
          <div className="w-16 h-16 rounded-2xl bg-cricket-gold/10 flex items-center justify-center shrink-0">
            <Trophy className="w-8 h-8 text-cricket-gold" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-start justify-between gap-3">
              <h1 className="font-display text-3xl font-bold">{tournament.name}</h1>
              {isAdmin && (
                <select value={tournament.status} onChange={e => handleStatusChange(e.target.value as Tournament['status'])}
                  className="px-2 py-1 rounded-lg border text-xs bg-background">
                  <option value="upcoming">Upcoming</option>
                  <option value="ongoing">Ongoing</option>
                  <option value="completed">Completed</option>
                </select>
              )}
            </div>
            <div className="flex flex-wrap gap-3 mt-2 text-sm text-muted-foreground">
              <span className="capitalize">{tournament.format.replace('+', ' + ')}</span>
              <span>•</span>
              <span>{tournament.overs} overs</span>
              <span>•</span>
              <span>{tournament.teamIds.length} teams</span>
            </div>
            {tournament.description && <p className="text-sm text-muted-foreground mt-2">{tournament.description}</p>}
            <div className="flex gap-4 mt-3 text-xs text-muted-foreground">
              <span>📅 {tournament.startDate?.toDate?.()?.toLocaleDateString()} – {tournament.endDate?.toDate?.()?.toLocaleDateString()}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex rounded-xl bg-muted p-1 mb-6 max-w-sm">
        {(['table', 'fixtures', 'teams'] as const).map(t => (
          <button key={t} onClick={() => setTab(t)} className={`flex-1 py-2 text-sm font-medium rounded-lg transition-all capitalize ${tab === t ? 'bg-background shadow text-foreground' : 'text-muted-foreground'}`}>{t}</button>
        ))}
      </div>

      {/* Points Table */}
      {tab === 'table' && (
        <div className="cricket-card overflow-hidden">
          <div className="px-4 py-3 border-b bg-muted/30 flex items-center justify-between">
            <h2 className="font-display font-bold">Points Table</h2>
          </div>
          {pointsTable.length === 0 ? (
            <div className="text-center py-10 text-muted-foreground">No teams yet. Add teams to see the table.</div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full min-w-[600px]">
                <thead>
                  <tr className="text-xs text-muted-foreground border-b bg-muted/20">
                    <th className="text-left px-4 py-2">#</th>
                    <th className="text-left px-4 py-2">Team</th>
                    <th className="text-center px-3 py-2">M</th>
                    <th className="text-center px-3 py-2">W</th>
                    <th className="text-center px-3 py-2">L</th>
                    <th className="text-center px-3 py-2">T</th>
                    <th className="text-center px-3 py-2">NR</th>
                    <th className="text-center px-3 py-2">Pts</th>
                    <th className="text-right px-4 py-2">NRR</th>
                  </tr>
                </thead>
                <tbody>
                  {pointsTable.map((entry, i) => (
                    <tr key={entry.teamId} className={`border-b last:border-0 ${i % 2 === 0 ? '' : 'bg-muted/10'}`}>
                      <td className="px-4 py-3 text-sm font-mono text-muted-foreground">{i + 1}</td>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-2">
                          {entry.teamLogoURL ? (
                            <img src={entry.teamLogoURL} alt="" className="w-7 h-7 rounded-full object-cover" />
                          ) : (
                            <div className="w-7 h-7 rounded-full bg-muted flex items-center justify-center text-sm font-bold">{entry.teamName[0]}</div>
                          )}
                          <Link href={`/teams/${entry.teamId}`} className="text-sm font-medium hover:text-primary transition-colors">{entry.teamName}</Link>
                        </div>
                      </td>
                      <td className="px-3 py-3 text-center text-sm font-mono">{entry.matchesPlayed}</td>
                      <td className="px-3 py-3 text-center text-sm font-mono text-green-500 font-semibold">{entry.wins}</td>
                      <td className="px-3 py-3 text-center text-sm font-mono text-red-500">{entry.losses}</td>
                      <td className="px-3 py-3 text-center text-sm font-mono">{entry.ties}</td>
                      <td className="px-3 py-3 text-center text-sm font-mono text-muted-foreground">{entry.noResult}</td>
                      <td className="px-3 py-3 text-center">
                        <span className="font-display text-base font-bold text-primary">{entry.points}</span>
                      </td>
                      <td className={`px-4 py-3 text-right text-sm font-mono font-semibold ${entry.netRunRate >= 0 ? 'text-green-500' : 'text-red-500'}`}>
                        {entry.netRunRate >= 0 ? '+' : ''}{entry.netRunRate.toFixed(3)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* Fixtures */}
      {tab === 'fixtures' && (
        <div className="space-y-3">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-display font-bold text-lg">Fixtures ({matches.length})</h2>
            {(isAdmin || isScorer) && (
              <Link href={`/matches/create?tournament=${id}`} className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 transition-colors">
                <Plus className="w-4 h-4" /> Add Match
              </Link>
            )}
          </div>
          {matches.length === 0 ? (
            <div className="text-center py-10 cricket-card text-muted-foreground">
              <Calendar className="w-10 h-10 mx-auto mb-3 opacity-30" />
              No fixtures yet
            </div>
          ) : matches.map(m => (
            <Link key={m.id} href={`/matches/${m.id}`}>
              <div className="cricket-card p-4 hover:border-primary/30 transition-all">
                <div className="flex items-center gap-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${m.status === 'live' ? 'text-red-500 bg-red-500/10' : m.status === 'completed' ? 'text-green-500 bg-green-500/10' : 'text-blue-500 bg-blue-500/10'}`}>
                        {m.status === 'live' ? 'LIVE' : m.status}
                      </span>
                    </div>
                    <p className="text-sm font-semibold">{m.teamA.name} vs {m.teamB.name}</p>
                    {m.result && <p className="text-xs text-primary mt-1">{m.result.resultText}</p>}
                  </div>
                  <div className="text-right text-xs text-muted-foreground">
                    <p>{m.date?.toDate?.()?.toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })}</p>
                    <p>{m.ground}</p>
                  </div>
                </div>
              </div>
            </Link>
          ))}
        </div>
      )}

      {/* Teams */}
      {tab === 'teams' && (
        <div>
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-display font-bold text-lg flex items-center gap-2">
              <Users className="w-5 h-5" /> Teams ({tournament.teamIds.length})
            </h2>
            {(isAdmin || isScorer) && (
              <button onClick={() => setShowAddTeam(true)} className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 transition-colors">
                <Plus className="w-4 h-4" /> Add Team
              </button>
            )}
          </div>

          {showAddTeam && availableTeams.length > 0 && (
            <div className="cricket-card p-4 mb-4">
              <p className="text-sm font-medium mb-3">Select team to add:</p>
              <div className="grid sm:grid-cols-2 gap-2">
                {availableTeams.map(team => (
                  <button key={team.id} onClick={() => handleAddTeam(team.id)}
                    className="flex items-center gap-3 p-3 rounded-xl border hover:border-primary/50 hover:bg-muted/50 transition-all text-left">
                    {team.logoURL ? (
                      <img src={team.logoURL} alt="" className="w-8 h-8 rounded-full object-cover" />
                    ) : (
                      <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center font-bold">{team.name[0]}</div>
                    )}
                    <span className="text-sm font-medium">{team.name}</span>
                  </button>
                ))}
              </div>
            </div>
          )}

          <div className="grid sm:grid-cols-2 gap-3">
            {tournament.teamIds.map(teamId => {
              const team = allTeams.find(t => t.id === teamId);
              if (!team) return null;
              return (
                <Link key={teamId} href={`/teams/${teamId}`}>
                  <div className="cricket-card p-4 flex items-center gap-3 hover:border-primary/30 transition-all">
                    {team.logoURL ? (
                      <img src={team.logoURL} alt="" className="w-10 h-10 rounded-full object-cover" />
                    ) : (
                      <div className="w-10 h-10 rounded-full bg-muted flex items-center justify-center font-bold">{team.name[0]}</div>
                    )}
                    <div>
                      <p className="font-semibold">{team.name}</p>
                      <p className="text-xs text-muted-foreground">Captain: {team.captainName}</p>
                    </div>
                  </div>
                </Link>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
