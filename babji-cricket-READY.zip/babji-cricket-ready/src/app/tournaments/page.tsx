'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { getAllTournaments, createTournament } from '@/lib/services';
import { useAuth } from '@/lib/auth-context';
import type { Tournament } from '@/types';
import toast from 'react-hot-toast';
import { Plus, Trophy, Calendar, X, Search } from 'lucide-react';

export default function TournamentsPage() {
  const [tournaments, setTournaments] = useState<Tournament[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCreate, setShowCreate] = useState(false);
  const [search, setSearch] = useState('');
  const { user, isAdmin, isScorer } = useAuth();

  useEffect(() => {
    getAllTournaments().then(setTournaments).finally(() => setLoading(false));
  }, []);

  const filtered = tournaments.filter(t => t.name.toLowerCase().includes(search.toLowerCase()));

  const statusColor = (s: Tournament['status']) =>
    s === 'ongoing' ? 'text-green-500 bg-green-500/10' :
    s === 'upcoming' ? 'text-blue-500 bg-blue-500/10' :
    'text-muted-foreground bg-muted';

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="font-display text-3xl font-bold">Tournaments</h1>
          <p className="text-muted-foreground mt-1">{tournaments.length} tournament{tournaments.length !== 1 ? 's' : ''}</p>
        </div>
        {(isAdmin || isScorer) && (
          <button onClick={() => setShowCreate(true)} className="flex items-center gap-2 px-4 py-2 rounded-xl bg-primary text-primary-foreground font-medium text-sm hover:bg-primary/90 transition-colors">
            <Plus className="w-4 h-4" /> New Tournament
          </button>
        )}
      </div>

      <div className="relative mb-6 max-w-md">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search tournaments..." className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-input bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring" />
      </div>

      {loading ? (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">{Array.from({ length: 6 }).map((_, i) => <div key={i} className="cricket-card h-40 skeleton" />)}</div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-16 cricket-card">
          <Trophy className="w-12 h-12 text-muted-foreground/30 mx-auto mb-4" />
          <p className="text-muted-foreground">No tournaments yet</p>
        </div>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map(t => (
            <Link key={t.id} href={`/tournaments/${t.id}`}>
              <div className="cricket-card p-5 hover:border-primary/30 transition-all h-full">
                <div className="flex items-start justify-between mb-3">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-cricket-gold/20 to-cricket-gold/5 flex items-center justify-center">
                    <Trophy className="w-6 h-6 text-cricket-gold" />
                  </div>
                  <span className={`text-xs font-medium px-2 py-0.5 rounded-full capitalize ${statusColor(t.status)}`}>{t.status}</span>
                </div>
                <h3 className="font-display font-bold text-lg mb-1 line-clamp-2">{t.name}</h3>
                <p className="text-xs text-muted-foreground capitalize mb-3">{t.format.replace('+', ' + ')} • {t.overs} overs</p>
                <div className="flex items-center justify-between text-xs text-muted-foreground border-t pt-3">
                  <span className="flex items-center gap-1"><Calendar className="w-3.5 h-3.5" />{t.startDate?.toDate?.()?.toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })}</span>
                  <span>{t.teamIds?.length || 0} teams</span>
                </div>
              </div>
            </Link>
          ))}
        </div>
      )}

      {showCreate && (
        <CreateTournamentModal
          userId={user!.id}
          onClose={() => setShowCreate(false)}
          onCreated={(t) => { setTournaments(prev => [t, ...prev]); setShowCreate(false); }}
        />
      )}
    </div>
  );
}

function CreateTournamentModal({ userId, onClose, onCreated }: { userId: string; onClose: () => void; onCreated: (t: Tournament) => void }) {
  const [name, setName] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [format, setFormat] = useState<Tournament['format']>('league');
  const [overs, setOvers] = useState(20);
  const [description, setDescription] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const id = await createTournament({
        name, format, overs, description,
        startDate: new Date(startDate) as any,
        endDate: new Date(endDate) as any,
        status: 'upcoming', teamIds: [], createdBy: userId,
      });
      const t: Tournament = { id, name, format, overs, description, startDate: new Date(startDate) as any, endDate: new Date(endDate) as any, status: 'upcoming', teamIds: [], createdBy: userId, createdAt: new Date() as any };
      onCreated(t);
      toast.success('Tournament created!');
    } catch (err: any) {
      toast.error(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
      <div className="w-full max-w-md cricket-card p-6 max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-display text-xl font-bold">Create Tournament</h2>
          <button onClick={onClose} className="p-1 rounded-lg hover:bg-muted"><X className="w-5 h-5" /></button>
        </div>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-1.5">Tournament Name *</label>
            <input value={name} onChange={e => setName(e.target.value)} required placeholder="Babji Cup 2025" className="w-full px-3 py-2.5 rounded-xl border border-input bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring" />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-sm font-medium mb-1.5">Start Date *</label>
              <input type="date" value={startDate} onChange={e => setStartDate(e.target.value)} required className="w-full px-3 py-2.5 rounded-xl border border-input bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring" />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1.5">End Date *</label>
              <input type="date" value={endDate} onChange={e => setEndDate(e.target.value)} required className="w-full px-3 py-2.5 rounded-xl border border-input bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring" />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-sm font-medium mb-1.5">Format</label>
              <select value={format} onChange={e => setFormat(e.target.value as Tournament['format'])} className="w-full px-3 py-2.5 rounded-xl border border-input bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring">
                <option value="league">League</option>
                <option value="knockout">Knockout</option>
                <option value="group+knockout">Group + Knockout</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium mb-1.5">Overs</label>
              <select value={overs} onChange={e => setOvers(Number(e.target.value))} className="w-full px-3 py-2.5 rounded-xl border border-input bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring">
                {[5, 10, 15, 20, 30, 40, 50].map(o => <option key={o} value={o}>{o}</option>)}
              </select>
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium mb-1.5">Description</label>
            <textarea value={description} onChange={e => setDescription(e.target.value)} rows={2} placeholder="About this tournament..." className="w-full px-3 py-2.5 rounded-xl border border-input bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring resize-none" />
          </div>
          <div className="flex gap-3 pt-2">
            <button type="button" onClick={onClose} className="flex-1 py-2.5 rounded-xl border text-sm font-medium hover:bg-muted">Cancel</button>
            <button type="submit" disabled={loading} className="flex-1 py-2.5 rounded-xl bg-primary text-primary-foreground text-sm font-medium disabled:opacity-50">
              {loading ? 'Creating...' : 'Create'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
