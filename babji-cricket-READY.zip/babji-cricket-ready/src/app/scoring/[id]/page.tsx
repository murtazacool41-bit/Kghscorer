'use client';
import { useEffect, useState, useCallback } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { subscribeToMatch, subscribeToInnings, getMatchInnings, updateMatch, addDoc, collection } from '@/lib/services';
import { processDelivery, addNewBatter, addNewBowler } from '@/lib/scoring-engine';
import { db } from '@/lib/firebase';
import { addDoc as fsAddDoc, collection as fsCollection, serverTimestamp } from 'firebase/firestore';
import { useAuth } from '@/lib/auth-context';
import type { Match, Innings, DismissalType } from '@/types';
import PlayerSearchInput from '@/components/cricket/PlayerSearchInput';
import type { Player } from '@/types';
import toast from 'react-hot-toast';
import { ArrowLeft, RotateCcw, AlertTriangle } from 'lucide-react';
import Link from 'next/link';

type ScoringModal = 'wicket' | 'newBatter' | 'newBowler' | 'inningsBreak' | null;

export default function ScoringPage() {
  const { id } = useParams<{ id: string }>();
  const { isScorer, isAdmin } = useAuth();
  const router = useRouter();

  const [match, setMatch] = useState<Match | null>(null);
  const [innings, setInnings] = useState<Innings | null>(null);
  const [allInnings, setAllInnings] = useState<Innings[]>([]);
  const [modal, setModal] = useState<ScoringModal>(null);
  const [wicketType, setWicketType] = useState<DismissalType>('bowled');
  const [dismissedId, setDismissedId] = useState('');
  const [fielderId, setFielderId] = useState('');
  const [fielderName, setFielderName] = useState('');
  const [processing, setProcessing] = useState(false);
  const [recentBalls, setRecentBalls] = useState<string[]>([]);

  useEffect(() => {
    if (!id) return;
    const unsub = subscribeToMatch(id, setMatch);
    return () => unsub();
  }, [id]);

  useEffect(() => {
    if (!match) return;
    getMatchInnings(id).then(inn => {
      setAllInnings(inn);
      const current = inn.find(i => i.inningsNumber === match.currentInnings);
      if (current) {
        setInnings(current);
      } else if (match.status === 'live' && match.battingFirstTeamId) {
        initFirstInnings();
      }
    });
  }, [match?.currentInnings, match?.status]);

  useEffect(() => {
    if (!innings?.id) return;
    const unsub = subscribeToInnings(innings.id, (updated) => {
      if (updated) setInnings(updated);
    });
    return () => unsub();
  }, [innings?.id]);

  const initFirstInnings = async () => {
    if (!match) return;
    const bowlingTeamId = match.battingFirstTeamId === match.teamA.id ? match.teamB.id : match.teamA.id;
    const newInnings: Omit<Innings, 'id'> = {
      matchId: id, inningsNumber: 1,
      battingTeamId: match.battingFirstTeamId!,
      bowlingTeamId,
      runs: 0, wickets: 0, overs: 0, balls: 0,
      extras: { wides: 0, noBalls: 0, byes: 0, legByes: 0, total: 0 },
      runRate: 0, isCompleted: false,
      batters: [], bowlers: [],
      partnerships: [], fallOfWickets: [],
      currentBatterIds: [], currentBowlerId: '',
      strikerBatterId: '', nonStrikerBatterId: '',
    };
    const ref = await fsAddDoc(fsCollection(db, 'innings'), newInnings);
    const created = { id: ref.id, ...newInnings };
    setInnings(created);
    setAllInnings([created]);
    setModal('newBatter');
  };

  const score = async (runs: number, extra?: 'wide' | 'no_ball' | 'bye' | 'leg_bye') => {
    if (!innings || !match || processing) return;
    if (!innings.strikerBatterId || !innings.currentBowlerId) {
      toast.error('Set batter and bowler first');
      return;
    }
    setProcessing(true);
    try {
      const { innings: updated, isOverComplete, isInningsComplete } = await processDelivery(id, innings.id, innings, {
        runs, extraType: extra, extraRuns: extra === 'wide' || extra === 'no_ball' ? 1 : runs,
      });

      const ballLabel = extra === 'wide' ? 'Wd' : extra === 'no_ball' ? 'Nb' : runs === 4 ? '4' : runs === 6 ? '6' : runs === 0 ? '•' : String(runs);
      setRecentBalls(prev => [...prev.slice(-23), ballLabel]);

      if (isInningsComplete) handleInningsComplete(updated);
      else if (isOverComplete) { toast.success('Over complete! Select new bowler'); setModal('newBowler'); }
    } catch (err: any) {
      toast.error(err.message);
    } finally {
      setProcessing(false);
    }
  };

  const handleWicket = async (runs = 0) => {
    if (!innings || !match || processing) return;
    const dismissed = innings.batters.find(b => b.playerId === (dismissedId || innings.strikerBatterId));
    setProcessing(true);
    try {
      const { innings: updated, isInningsComplete } = await processDelivery(id, innings.id, innings, {
        runs, isWicket: true, dismissalType: wicketType,
        dismissedPlayerId: dismissed?.playerId || innings.strikerBatterId,
        dismissedPlayerName: dismissed?.playerName,
        fielderId: fielderId || undefined,
        fielderName: fielderName || undefined,
      });
      setRecentBalls(prev => [...prev.slice(-23), 'W']);
      setModal(null);
      if (isInningsComplete) handleInningsComplete(updated);
      else setModal('newBatter');
    } catch (err: any) {
      toast.error(err.message);
    } finally {
      setProcessing(false);
    }
  };

  const handleInningsComplete = async (finalInnings: Innings) => {
    if (!match) return;
    const isSecondInnings = match.currentInnings === 2;
    if (isSecondInnings) {
      await completeMatch(finalInnings);
    } else {
      await updateMatch(id, {
        status: 'innings_break',
        currentInnings: 2,
        innings1: {
          teamId: finalInnings.battingTeamId,
          teamName: finalInnings.battingTeamId === match.teamA.id ? match.teamA.name : match.teamB.name,
          runs: finalInnings.runs, wickets: finalInnings.wickets,
          overs: finalInnings.overs, balls: finalInnings.balls,
          extras: finalInnings.extras, runRate: finalInnings.runRate,
          isCompleted: true,
        },
      });
      setModal('inningsBreak');
    }
  };

  const startSecondInnings = async () => {
    if (!match || !innings) return;
    const battingTeamId = innings.battingTeamId === match.teamA.id ? match.teamB.id : match.teamA.id;
    const bowlingTeamId = innings.battingTeamId;
    const target = innings.runs + 1;
    const newInn: Omit<Innings, 'id'> = {
      matchId: id, inningsNumber: 2,
      battingTeamId, bowlingTeamId,
      runs: 0, wickets: 0, overs: 0, balls: 0,
      extras: { wides: 0, noBalls: 0, byes: 0, legByes: 0, total: 0 },
      runRate: 0, targetRuns: target,
      requiredRunRate: target / match.overs,
      isCompleted: false,
      batters: [], bowlers: [],
      partnerships: [], fallOfWickets: [],
      currentBatterIds: [], currentBowlerId: '',
      strikerBatterId: '', nonStrikerBatterId: '',
    };
    const ref = await fsAddDoc(fsCollection(db, 'innings'), newInn);
    const created = { id: ref.id, ...newInn };
    setInnings(created);
    await updateMatch(id, { status: 'live', currentInnings: 2 });
    setModal('newBatter');
    setRecentBalls([]);
    toast.success(`Target: ${target} runs`);
  };

  const completeMatch = async (finalInnings: Innings) => {
    if (!match) return;
    const inn1 = allInnings.find(i => i.inningsNumber === 1);
    if (!inn1) return;
    const inn2Runs = finalInnings.runs;
    const inn1Runs = inn1.runs;
    let resultText = '';
    let winnerId = '';
    if (inn2Runs > inn1Runs) {
      const wicketsLeft = 10 - finalInnings.wickets;
      winnerId = finalInnings.battingTeamId;
      const winnerName = winnerId === match.teamA.id ? match.teamA.name : match.teamB.name;
      resultText = `${winnerName} won by ${wicketsLeft} wicket${wicketsLeft !== 1 ? 's' : ''}`;
    } else if (inn1Runs > inn2Runs) {
      winnerId = inn1.battingTeamId;
      const winnerName = winnerId === match.teamA.id ? match.teamA.name : match.teamB.name;
      resultText = `${winnerName} won by ${inn1Runs - inn2Runs} run${inn1Runs - inn2Runs !== 1 ? 's' : ''}`;
    } else {
      resultText = 'Match tied!';
    }
    await updateMatch(id, {
      status: 'completed',
      innings2: {
        teamId: finalInnings.battingTeamId,
        teamName: finalInnings.battingTeamId === match.teamA.id ? match.teamA.name : match.teamB.name,
        runs: finalInnings.runs, wickets: finalInnings.wickets,
        overs: finalInnings.overs, balls: finalInnings.balls,
        extras: finalInnings.extras, runRate: finalInnings.runRate,
        isCompleted: true,
      },
      result: winnerId ? { winnerId, winnerName: winnerId === match.teamA.id ? match.teamA.name : match.teamB.name, resultText } : { winnerId: '', winnerName: 'Tie', resultText },
    });
    toast.success(resultText);
    router.push(`/matches/${id}`);
  };

  if (!match) return <div className="flex items-center justify-center min-h-screen text-muted-foreground">Loading...</div>;
  if (!isScorer && !isAdmin) return <div className="flex items-center justify-center min-h-screen"><p>Scorer access required</p></div>;

  const striker = innings?.batters.find(b => b.playerId === innings?.strikerBatterId);
  const nonStriker = innings?.batters.find(b => b.playerId === innings?.nonStrikerBatterId);
  const bowler = innings?.bowlers.find(b => b.playerId === innings?.currentBowlerId);
  const battingTeamName = innings ? (innings.battingTeamId === match.teamA.id ? match.teamA.name : match.teamB.name) : '';

  return (
    <div className="min-h-screen bg-cricket-navy text-white">
      {/* Top Bar */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-white/10">
        <Link href={`/matches/${id}`} className="flex items-center gap-2 text-white/70 hover:text-white transition-colors text-sm">
          <ArrowLeft className="w-4 h-4" /> Exit
        </Link>
        <span className="live-badge">Live Scoring</span>
        <span className="text-sm text-white/50">{match.overs} Overs</span>
      </div>

      {/* Score Display */}
      {innings && (
        <div className="px-4 py-6 text-center border-b border-white/10">
          <p className="text-white/60 text-sm mb-1">{battingTeamName}</p>
          <p className="font-display text-6xl font-bold text-white">
            {innings.runs}/{innings.wickets}
          </p>
          <p className="text-white/60 mt-1">
            {innings.overs}.{innings.balls} ov • RR: {innings.runRate.toFixed(2)}
            {innings.targetRuns && (
              <span className="ml-2 text-cricket-gold">• Need {innings.targetRuns - innings.runs} off {(match.overs - innings.overs) * 6 - innings.balls} balls • RRR: {innings.requiredRunRate?.toFixed(2)}</span>
            )}
          </p>

          {/* Recent balls */}
          {recentBalls.length > 0 && (
            <div className="flex items-center justify-center gap-1.5 mt-4 flex-wrap">
              {recentBalls.slice(-12).map((b, i) => (
                <span key={i} className={`ball-chip ${b === 'W' ? 'wicket' : b === '4' ? 'four' : b === '6' ? 'six' : b === '•' ? 'dot' : b === 'Wd' || b === 'Nb' ? 'wide' : 'runs'}`}>{b === '•' ? '0' : b}</span>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Current Batters & Bowler */}
      {innings && (
        <div className="px-4 py-3 grid grid-cols-3 gap-2 border-b border-white/10 text-sm">
          <BatterMini label="Striker" name={striker?.playerName || '—'} runs={striker?.runs} balls={striker?.balls} />
          <BatterMini label="Non-Striker" name={nonStriker?.playerName || '—'} runs={nonStriker?.runs} balls={nonStriker?.balls} />
          <div className="text-center">
            <p className="text-white/50 text-xs mb-1">Bowler</p>
            <p className="font-medium truncate">{bowler?.playerName || '—'}</p>
            <p className="text-white/50 text-xs">{bowler ? `${bowler.overs}.${bowler.balls % 6}-${bowler.maidens}-${bowler.runs}-${bowler.wickets}` : '—'}</p>
          </div>
        </div>
      )}

      {/* Scoring Buttons */}
      <div className="p-4 space-y-3 max-w-lg mx-auto">
        {/* Runs */}
        <div className="grid grid-cols-6 gap-2">
          {[0, 1, 2, 3, 4, 6].map(r => (
            <button key={r} onClick={() => score(r)} disabled={processing || !innings?.currentBowlerId}
              className={`score-button h-14 ${r === 4 ? 'four-button' : r === 6 ? 'six-button' : 'run-button'} disabled:opacity-40`}>
              {r}
            </button>
          ))}
        </div>

        {/* Extras */}
        <div className="grid grid-cols-4 gap-2">
          {(['wide', 'no_ball', 'bye', 'leg_bye'] as const).map(ext => (
            <button key={ext} onClick={() => score(ext === 'wide' || ext === 'no_ball' ? 0 : 1, ext)}
              disabled={processing || !innings?.currentBowlerId}
              className="extra-button h-11 text-sm disabled:opacity-40">
              {ext === 'wide' ? 'Wide' : ext === 'no_ball' ? 'No Ball' : ext === 'bye' ? 'Bye' : 'Leg Bye'}
            </button>
          ))}
        </div>

        {/* Wicket */}
        <button onClick={() => setModal('wicket')} disabled={processing || !innings?.currentBowlerId}
          className="wicket-button w-full h-12 flex items-center justify-center gap-2 disabled:opacity-40">
          <AlertTriangle className="w-5 h-5" /> WICKET
        </button>

        {/* Controls */}
        <div className="grid grid-cols-2 gap-2 pt-2">
          <button onClick={() => setModal('newBowler')} className="py-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-sm font-medium transition-colors">
            🎳 Change Bowler
          </button>
          <button onClick={() => innings && setModal('newBatter')} className="py-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-sm font-medium transition-colors">
            🏏 Send Batter
          </button>
        </div>
      </div>

      {/* Wicket Modal */}
      {modal === 'wicket' && innings && (
        <Modal title="Wicket!" onClose={() => setModal(null)}>
          <div className="space-y-4">
            <div>
              <label className="text-sm text-white/70 mb-2 block">Dismissed Batter</label>
              <select value={dismissedId || innings.strikerBatterId} onChange={e => setDismissedId(e.target.value)}
                className="w-full px-3 py-2 rounded-lg bg-white/10 border border-white/20 text-white text-sm">
                {innings.batters.filter(b => !b.isOut).map(b => (
                  <option key={b.playerId} value={b.playerId}>{b.playerName}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="text-sm text-white/70 mb-2 block">Dismissal Type</label>
              <div className="grid grid-cols-3 gap-2">
                {(['bowled', 'caught', 'run_out', 'lbw', 'stumped', 'hit_wicket'] as DismissalType[]).map(d => (
                  <button key={d} onClick={() => setWicketType(d)}
                    className={`py-2 rounded-lg text-sm font-medium transition-colors capitalize ${wicketType === d ? 'bg-red-500 text-white' : 'bg-white/10 text-white/70 hover:bg-white/20'}`}>
                    {d.replace('_', ' ')}
                  </button>
                ))}
              </div>
            </div>
            {(wicketType === 'caught' || wicketType === 'stumped' || wicketType === 'run_out') && (
              <div>
                <label className="text-sm text-white/70 mb-2 block">Fielder Name</label>
                <input value={fielderName} onChange={e => setFielderName(e.target.value)} placeholder="Fielder name"
                  className="w-full px-3 py-2 rounded-lg bg-white/10 border border-white/20 text-white text-sm placeholder-white/40" />
              </div>
            )}
            <button onClick={() => handleWicket()} disabled={processing}
              className="w-full py-3 rounded-xl bg-red-500 hover:bg-red-600 text-white font-bold transition-colors disabled:opacity-50">
              Confirm Wicket
            </button>
          </div>
        </Modal>
      )}

      {/* New Batter Modal */}
      {modal === 'newBatter' && innings && (
        <Modal title="Send Next Batter" onClose={() => setModal(null)}>
          <div className="[&_input]:text-black [&_input]:bg-white [&_input]:border-gray-300 [&_p]:text-white/70 [&_.text-foreground]:text-black [&_.text-muted-foreground]:text-gray-500 [&_.bg-muted]:bg-gray-100 [&_.border-border]:border-gray-300 [&_.bg-popover]:bg-white [&_.text-primary]:text-green-600 [&_.bg-primary]:bg-green-500">
            <PlayerSearchInput
              placeholder="Type batter name..."
              excludeIds={innings.batters.filter(b => !b.isOut).map(b => b.playerId)}
              onSelect={async (p) => {
                if ('isNew' in p) return;
                await addNewBatter(innings.id, p.id, p.name, innings);
                setModal(null);
                toast.success(`${p.name} is batting`);
              }}
            />
          </div>
        </Modal>
      )}

      {/* New Bowler Modal */}
      {modal === 'newBowler' && innings && (
        <Modal title="Select Bowler" onClose={() => setModal(null)}>
          <div className="[&_input]:text-black [&_input]:bg-white [&_input]:border-gray-300 [&_p]:text-white/70 [&_.text-foreground]:text-black [&_.text-muted-foreground]:text-gray-500 [&_.bg-muted]:bg-gray-100 [&_.border-border]:border-gray-300 [&_.bg-popover]:bg-white [&_.text-primary]:text-green-600">
            <PlayerSearchInput
              placeholder="Type bowler name..."
              onSelect={async (p) => {
                if ('isNew' in p) return;
                await addNewBowler(innings.id, p.id, p.name, innings);
                setModal(null);
                toast.success(`${p.name} is bowling`);
              }}
            />
          </div>
        </Modal>
      )}

      {/* Innings Break Modal */}
      {modal === 'inningsBreak' && innings && (
        <Modal title="Innings Complete!" onClose={() => {}}>
          <div className="text-center space-y-4">
            <p className="text-2xl font-display font-bold">{innings.runs}/{innings.wickets}</p>
            <p className="text-white/70">({innings.overs}.{innings.balls} overs)</p>
            <div className="p-4 rounded-xl bg-cricket-gold/20 border border-cricket-gold/30">
              <p className="text-cricket-gold font-bold text-lg">Target: {innings.runs + 1} runs</p>
            </div>
            <button onClick={startSecondInnings} className="w-full py-3 rounded-xl bg-cricket-green hover:bg-green-600 text-white font-bold transition-colors">
              Start 2nd Innings →
            </button>
          </div>
        </Modal>
      )}
    </div>
  );
}

function BatterMini({ label, name, runs, balls }: { label: string; name: string; runs?: number; balls?: number }) {
  return (
    <div className="text-center">
      <p className="text-white/50 text-xs mb-1">{label}</p>
      <p className="font-medium text-sm truncate">{name}</p>
      {runs !== undefined && <p className="text-white/50 text-xs">{runs}({balls})</p>}
    </div>
  );
}

function Modal({ title, children, onClose }: { title: string; children: React.ReactNode; onClose: () => void }) {
  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
      <div className="w-full max-w-md rounded-t-2xl sm:rounded-2xl bg-cricket-navy border border-white/10 p-5">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-display text-lg font-bold text-white">{title}</h3>
          {onClose && <button onClick={onClose} className="text-white/50 hover:text-white transition-colors text-xl leading-none">×</button>}
        </div>
        {children}
      </div>
    </div>
  );
}
