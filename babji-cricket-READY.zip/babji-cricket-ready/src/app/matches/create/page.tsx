'use client';
import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { getAllTeams, getAllTournaments, createMatch } from '@/lib/services';
import { useAuth } from '@/lib/auth-context';
import type { Team, Tournament } from '@/types';
import toast from 'react-hot-toast';
import { ArrowLeft, Calendar, MapPin, Clock, Trophy } from 'lucide-react';
import Link from 'next/link';

export default function CreateMatchPage() {
  const router = useRouter();
  const { user, isScorer, isAdmin, loading: authLoading } = useAuth();
  const [teams, setTeams] = useState<Team[]>([]);
  const [tournaments, setTournaments] = useState<Tournament[]>([]);
  const [loading, setLoading] = useState(false);

  const [teamAId, setTeamAId] = useState('');
  const [teamBId, setTeamBId] = useState('');
  const [ground, setGround] = useState('');
  const [date, setDate] = useState(new Date().toISOString().slice(0, 16));
  const [overs, setOvers] = useState(20);
  const [tournamentId, setTournamentId] = useState('');

  useEffect(() => {
    Promise.all([getAllTeams(), getAllTournaments()]).then(([t, to]) => { setTeams(t); setTournaments(to); });
  }, []);

  useEffect(() => {
    if (!authLoading && !isScorer && !isAdmin) {
      toast.error('You need scorer or admin access');
      router.push('/matches');
    }
  }, [authLoading, isScorer, isAdmin]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (teamAId === teamBId) { toast.error('Teams must be different'); return; }
    setLoading(true);
    try {
      const teamA = teams.find(t => t.id === teamAId)!;
      const teamB = teams.find(t => t.id === teamBId)!;
      const tournament = tournaments.find(t => t.id === tournamentId);
      const id = await createMatch({
        teamA: { id: teamA.id, name: teamA.name, logoURL: teamA.logoURL },
        teamB: { id: teamB.id, name: teamB.name, logoURL: teamB.logoURL },
        ground, date: new Date(date) as any, overs,
        tournamentId: tournamentId || undefined,
        tournamentName: tournament?.name,
        createdBy: user!.id,
      });
      toast.success('Match created!');
      router.push(`/matches/${id}`);
    } catch (err: any) {
      toast.error(err.message || 'Failed to create match');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto px-4 sm:px-6 py-8">
      <Link href="/matches" className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground mb-6 transition-colors">
        <ArrowLeft className="w-4 h-4" /> All Matches
      </Link>

      <div className="mb-6">
        <h1 className="font-display text-3xl font-bold">Create Match</h1>
        <p className="text-muted-foreground mt-1">Set up a new cricket match</p>
      </div>

      <form onSubmit={handleSubmit} className="cricket-card p-6 space-y-5">
        {/* Teams */}
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium mb-1.5">Team A *</label>
            <select value={teamAId} onChange={e => setTeamAId(e.target.value)} required className="w-full px-3 py-2.5 rounded-xl border border-input bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring">
              <option value="">Select team</option>
              {teams.map(t => <option key={t.id} value={t.id}>{t.name}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium mb-1.5">Team B *</label>
            <select value={teamBId} onChange={e => setTeamBId(e.target.value)} required className="w-full px-3 py-2.5 rounded-xl border border-input bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring">
              <option value="">Select team</option>
              {teams.filter(t => t.id !== teamAId).map(t => <option key={t.id} value={t.id}>{t.name}</option>)}
            </select>
          </div>
        </div>

        {/* Team preview */}
        {teamAId && teamBId && (
          <div className="flex items-center justify-center gap-4 p-4 rounded-xl bg-muted/50 border border-border">
            <TeamBadge team={teams.find(t => t.id === teamAId)!} />
            <span className="font-display text-xl font-bold text-muted-foreground">VS</span>
            <TeamBadge team={teams.find(t => t.id === teamBId)!} />
          </div>
        )}

        {/* Ground */}
        <div>
          <label className="block text-sm font-medium mb-1.5 flex items-center gap-1.5"><MapPin className="w-4 h-4" /> Ground *</label>
          <input value={ground} onChange={e => setGround(e.target.value)} required placeholder="Shivaji Park, Mumbai" className="w-full px-3 py-2.5 rounded-xl border border-input bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring" />
        </div>

        {/* Date & Overs */}
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium mb-1.5 flex items-center gap-1.5"><Calendar className="w-4 h-4" /> Date & Time *</label>
            <input type="datetime-local" value={date} onChange={e => setDate(e.target.value)} required className="w-full px-3 py-2.5 rounded-xl border border-input bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring" />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1.5 flex items-center gap-1.5"><Clock className="w-4 h-4" /> Overs *</label>
            <select value={overs} onChange={e => setOvers(Number(e.target.value))} className="w-full px-3 py-2.5 rounded-xl border border-input bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring">
              {[5, 6, 8, 10, 12, 15, 20, 25, 30, 35, 40, 45, 50].map(o => <option key={o} value={o}>{o} overs</option>)}
            </select>
          </div>
        </div>

        {/* Tournament (optional) */}
        <div>
          <label className="block text-sm font-medium mb-1.5 flex items-center gap-1.5"><Trophy className="w-4 h-4" /> Tournament <span className="text-muted-foreground font-normal">(optional)</span></label>
          <select value={tournamentId} onChange={e => setTournamentId(e.target.value)} className="w-full px-3 py-2.5 rounded-xl border border-input bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring">
            <option value="">No tournament</option>
            {tournaments.map(t => <option key={t.id} value={t.id}>{t.name}</option>)}
          </select>
        </div>

        <div className="pt-2">
          <button type="submit" disabled={loading} className="w-full py-3 rounded-xl bg-primary text-primary-foreground font-semibold hover:bg-primary/90 transition-colors disabled:opacity-50">
            {loading ? 'Creating...' : 'Create Match & Set Toss →'}
          </button>
        </div>
      </form>

      {teams.length === 0 && (
        <div className="mt-4 p-4 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-600 text-sm">
          No teams yet. <Link href="/teams" className="underline">Create teams first</Link> before making a match.
        </div>
      )}
    </div>
  );
}

function TeamBadge({ team }: { team: Team }) {
  return (
    <div className="flex flex-col items-center gap-2">
      {team.logoURL ? (
        <img src={team.logoURL} alt={team.name} className="w-12 h-12 rounded-full object-cover" />
      ) : (
        <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center font-bold text-primary text-lg">{team.name[0]}</div>
      )}
      <span className="text-sm font-semibold text-center">{team.name}</span>
    </div>
  );
}
