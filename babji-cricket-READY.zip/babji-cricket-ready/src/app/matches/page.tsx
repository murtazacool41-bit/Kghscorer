'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { getAllMatches } from '@/lib/services';
import { useAuth } from '@/lib/auth-context';
import type { Match } from '@/types';
import { Plus, Calendar, Search, Zap, Clock, CheckCircle, XCircle } from 'lucide-react';

export default function MatchesPage() {
  const [matches, setMatches] = useState<Match[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<'all' | 'live' | 'upcoming' | 'completed'>('all');
  const [search, setSearch] = useState('');
  const { isAdmin, isScorer } = useAuth();

  useEffect(() => {
    getAllMatches().then(setMatches).finally(() => setLoading(false));
  }, []);

  const filtered = matches
    .filter(m => filter === 'all' || (filter === 'live' && m.status === 'live') || (filter === 'upcoming' && ['upcoming', 'toss'].includes(m.status)) || (filter === 'completed' && m.status === 'completed'))
    .filter(m => search === '' || m.teamA.name.toLowerCase().includes(search.toLowerCase()) || m.teamB.name.toLowerCase().includes(search.toLowerCase()) || m.ground?.toLowerCase().includes(search.toLowerCase()));

  const tabs = [
    { key: 'all', label: 'All', icon: Calendar },
    { key: 'live', label: 'Live', icon: Zap },
    { key: 'upcoming', label: 'Upcoming', icon: Clock },
    { key: 'completed', label: 'Results', icon: CheckCircle },
  ] as const;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="font-display text-3xl font-bold">Matches</h1>
          <p className="text-muted-foreground mt-1">{matches.length} total matches</p>
        </div>
        {(isAdmin || isScorer) && (
          <Link href="/matches/create" className="flex items-center gap-2 px-4 py-2 rounded-xl bg-primary text-primary-foreground font-medium text-sm hover:bg-primary/90 transition-colors">
            <Plus className="w-4 h-4" /> New Match
          </Link>
        )}
      </div>

      <div className="flex flex-col sm:flex-row gap-3 mb-6">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search by team or ground..." className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-input bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring" />
        </div>
        <div className="flex gap-2">
          {tabs.map(({ key, label, icon: Icon }) => (
            <button key={key} onClick={() => setFilter(key)} className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium transition-colors ${filter === key ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground hover:text-foreground'}`}>
              <Icon className="w-3.5 h-3.5" />{label}
            </button>
          ))}
        </div>
      </div>

      {loading ? (
        <div className="space-y-3">{Array.from({ length: 5 }).map((_, i) => <div key={i} className="cricket-card h-28 skeleton" />)}</div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-16 cricket-card">
          <Calendar className="w-12 h-12 text-muted-foreground/30 mx-auto mb-4" />
          <p className="text-muted-foreground">No matches found</p>
          {(isAdmin || isScorer) && (
            <Link href="/matches/create" className="inline-block mt-4 px-4 py-2 rounded-xl bg-primary text-primary-foreground text-sm font-medium">Create First Match</Link>
          )}
        </div>
      ) : (
        <div className="space-y-3">
          {filtered.map(match => <MatchRow key={match.id} match={match} />)}
        </div>
      )}
    </div>
  );
}

function MatchRow({ match }: { match: Match }) {
  const statusConfig = {
    live: { label: 'LIVE', class: 'live-badge' },
    upcoming: { label: 'Upcoming', class: 'text-xs font-medium text-blue-500 bg-blue-500/10 px-2 py-0.5 rounded-full' },
    toss: { label: 'Toss', class: 'text-xs font-medium text-amber-500 bg-amber-500/10 px-2 py-0.5 rounded-full' },
    completed: { label: 'Completed', class: 'text-xs font-medium text-green-500 bg-green-500/10 px-2 py-0.5 rounded-full' },
    innings_break: { label: 'Break', class: 'text-xs font-medium text-purple-500 bg-purple-500/10 px-2 py-0.5 rounded-full' },
    abandoned: { label: 'Abandoned', class: 'text-xs font-medium text-muted-foreground bg-muted px-2 py-0.5 rounded-full' },
  };
  const s = statusConfig[match.status] || statusConfig.upcoming;
  const date = match.date?.toDate?.() || new Date();

  return (
    <Link href={`/matches/${match.id}`}>
      <div className={`cricket-card p-4 hover:border-primary/30 transition-all ${match.status === 'live' ? 'border-red-500/20' : ''}`}>
        <div className="flex items-start gap-4">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-3 mb-3">
              <span className={s.class}>{s.label}</span>
              <span className="text-xs text-muted-foreground">{match.overs} Overs</span>
              {match.tournamentName && <span className="text-xs text-muted-foreground truncate hidden sm:block">🏆 {match.tournamentName}</span>}
            </div>
            <div className="grid grid-cols-[1fr_auto_1fr] items-center gap-3">
              <TeamInningsDisplay name={match.teamA.name} logo={match.teamA.logoURL} summary={match.innings1} />
              <span className="text-xs font-bold text-muted-foreground">VS</span>
              <TeamInningsDisplay name={match.teamB.name} logo={match.teamB.logoURL} summary={match.innings2} right />
            </div>
            {match.result && (
              <p className="text-xs text-primary font-medium mt-3 pt-3 border-t truncate">{match.result.resultText}</p>
            )}
          </div>
          <div className="text-right shrink-0 text-xs text-muted-foreground hidden sm:block">
            <p>{date.toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })}</p>
            <p className="mt-1 truncate max-w-28">{match.ground}</p>
          </div>
        </div>
      </div>
    </Link>
  );
}

function TeamInningsDisplay({ name, logo, summary, right }: { name: string; logo?: string; summary?: Match['innings1']; right?: boolean }) {
  return (
    <div className={`flex items-center gap-2 ${right ? 'flex-row-reverse text-right' : ''}`}>
      {logo ? (
        <img src={logo} alt="" className="w-8 h-8 rounded-full object-cover shrink-0" />
      ) : (
        <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center font-bold text-sm shrink-0">{name[0]}</div>
      )}
      <div className={`min-w-0 ${right ? 'items-end' : ''} flex flex-col`}>
        <p className="text-sm font-semibold truncate max-w-28">{name}</p>
        {summary ? (
          <p className="font-display text-lg font-bold leading-tight">{summary.runs}/{summary.wickets} <span className="text-xs text-muted-foreground font-normal">({summary.overs}.{summary.balls})</span></p>
        ) : (
          <p className="text-xs text-muted-foreground">Yet to bat</p>
        )}
      </div>
    </div>
  );
}
