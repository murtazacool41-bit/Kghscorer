'use client';
import { useEffect, useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import Link from 'next/link';
import { subscribeToMatch, getMatchInnings, updateMatch } from '@/lib/services';
import { useAuth } from '@/lib/auth-context';
import { generateScorecard } from '@/lib/pdf-export';
import type { Match, Innings } from '@/types';
import toast from 'react-hot-toast';
import { ArrowLeft, Download, Share2, Zap, Users, Trophy } from 'lucide-react';

export default function MatchDetailPage() {
  const { id } = useParams<{ id: string }>();
  const [match, setMatch] = useState<Match | null>(null);
  const [innings, setInnings] = useState<Innings[]>([]);
  const [loading, setLoading] = useState(true);
  const { user, isScorer, isAdmin } = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (!id) return;
    const unsub = subscribeToMatch(id, (m) => {
      setMatch(m);
      setLoading(false);
    });
    getMatchInnings(id).then(setInnings);
    return () => unsub();
  }, [id]);

  const handleToss = async (winnerId: string, decision: 'bat' | 'bowl') => {
    if (!match) return;
    const winner = winnerId === match.teamA.id ? match.teamA : match.teamB;
    const battingFirst = decision === 'bat' ? winnerId : (winnerId === match.teamA.id ? match.teamB.id : match.teamA.id);
    await updateMatch(id, {
      status: 'live',
      tossWinnerId: winnerId,
      tossWinnerName: winner.name,
      tossDecision: decision,
      battingFirstTeamId: battingFirst,
    });
    toast.success(`${winner.name} won toss and chose to ${decision}`);
    router.push(`/scoring/${id}`);
  };

  const handleShare = () => {
    const url = `${window.location.origin}/matches/${id}`;
    navigator.clipboard.writeText(url);
    toast.success('Match link copied!');
  };

  const handlePDF = async () => {
    if (!match || innings.length === 0) return;
    await generateScorecard(match, innings[0], innings[1]);
  };

  if (loading) return <div className="max-w-4xl mx-auto px-4 py-12 text-center text-muted-foreground">Loading match...</div>;
  if (!match) return <div className="max-w-4xl mx-auto px-4 py-12 text-center">Match not found</div>;

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-8">
      <div className="flex items-center justify-between mb-6">
        <Link href="/matches" className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground">
          <ArrowLeft className="w-4 h-4" /> Matches
        </Link>
        <div className="flex gap-2">
          <button onClick={handleShare} className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border text-sm hover:bg-muted transition-colors">
            <Share2 className="w-4 h-4" /> Share
          </button>
          {match.status === 'completed' && innings.length > 0 && (
            <button onClick={handlePDF} className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border text-sm hover:bg-muted transition-colors">
              <Download className="w-4 h-4" /> PDF
            </button>
          )}
          {(isAdmin || isScorer) && match.status === 'live' && (
            <Link href={`/scoring/${id}`} className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-red-500 text-white text-sm font-medium hover:bg-red-600 transition-colors">
              <Zap className="w-4 h-4" /> Score
            </Link>
          )}
        </div>
      </div>

      {/* Match Header Card */}
      <div className={`cricket-card p-6 mb-6 ${match.status === 'live' ? 'border-red-500/30' : ''}`}>
        {match.status === 'live' && <div className="flex justify-center mb-4"><span className="live-badge">Live</span></div>}
        {match.tournamentName && (
          <p className="text-center text-xs text-muted-foreground mb-3 flex items-center justify-center gap-1">
            <Trophy className="w-3.5 h-3.5" /> {match.tournamentName}
          </p>
        )}

        <div className="grid grid-cols-[1fr_auto_1fr] items-center gap-4">
          <TeamScoreBlock team={match.teamA} innings={match.innings1} align="left" />
          <div className="text-center">
            <p className="font-display text-2xl font-bold text-muted-foreground">VS</p>
            <p className="text-xs text-muted-foreground mt-1">{match.overs} Ov</p>
          </div>
          <TeamScoreBlock team={match.teamB} innings={match.innings2} align="right" />
        </div>

        {match.result && (
          <div className="mt-4 pt-4 border-t text-center">
            <p className="font-semibold text-primary">{match.result.resultText}</p>
          </div>
        )}

        {match.tossWinnerName && (
          <p className="text-center text-xs text-muted-foreground mt-3">
            🪙 {match.tossWinnerName} won the toss and chose to {match.tossDecision}
          </p>
        )}

        <div className="flex items-center justify-center gap-4 mt-4 pt-4 border-t text-xs text-muted-foreground">
          <span>📍 {match.ground}</span>
          <span>•</span>
          <span>📅 {match.date?.toDate?.()?.toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}</span>
        </div>
      </div>

      {/* Toss Section */}
      {match.status === 'upcoming' && (isAdmin || isScorer) && (
        <div className="cricket-card p-6 mb-6">
          <h2 className="font-display text-xl font-bold mb-4 flex items-center gap-2">
            🪙 Toss
          </h2>
          <p className="text-sm text-muted-foreground mb-4">Who won the toss?</p>
          <div className="grid grid-cols-2 gap-4">
            {[match.teamA, match.teamB].map(team => (
              <div key={team.id} className="cricket-card p-4">
                <p className="font-semibold text-center mb-3">{team.name}</p>
                <div className="grid grid-cols-2 gap-2">
                  <button onClick={() => handleToss(team.id, 'bat')} className="py-2 rounded-lg bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 transition-colors">🏏 Bat</button>
                  <button onClick={() => handleToss(team.id, 'bowl')} className="py-2 rounded-lg bg-muted text-foreground text-sm font-medium hover:bg-muted/80 transition-colors">🎳 Bowl</button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Scorecards */}
      {innings.map((inn, i) => (
        <div key={inn.id} className="cricket-card mb-4 overflow-hidden">
          <div className="flex items-center justify-between px-5 py-3 bg-cricket-navy text-white">
            <h3 className="font-display font-bold">{inn.battingTeamId === match.teamA.id ? match.teamA.name : match.teamB.name} Innings</h3>
            <span className="font-display text-xl font-bold">{inn.runs}/{inn.wickets} <span className="text-sm font-normal opacity-70">({inn.overs}.{inn.balls})</span></span>
          </div>

          {/* Batting */}
          <div className="overflow-x-auto">
            <table className="w-full min-w-[500px]">
              <thead><tr className="bg-muted/50 text-xs text-muted-foreground">
                <th className="text-left px-4 py-2">Batter</th>
                <th className="text-left px-4 py-2">Dismissal</th>
                <th className="text-center px-3 py-2">R</th>
                <th className="text-center px-3 py-2">B</th>
                <th className="text-center px-3 py-2">4s</th>
                <th className="text-center px-3 py-2">6s</th>
                <th className="text-right px-4 py-2">SR</th>
              </tr></thead>
              <tbody>
                {inn.batters.map((b, idx) => (
                  <tr key={b.playerId} className={`border-t text-sm ${idx % 2 === 0 ? '' : 'bg-muted/20'} ${b.isOnStrike ? 'bg-primary/5' : ''}`}>
                    <td className="px-4 py-2.5 font-medium">
                      {b.playerName} {b.isOnStrike && <span className="text-primary">*</span>}
                    </td>
                    <td className="px-4 py-2.5 text-muted-foreground text-xs">{b.isOut ? b.dismissalDesc : 'not out'}</td>
                    <td className="px-3 py-2.5 text-center font-mono font-bold">{b.runs}</td>
                    <td className="px-3 py-2.5 text-center font-mono text-muted-foreground">{b.balls}</td>
                    <td className="px-3 py-2.5 text-center font-mono">{b.fours}</td>
                    <td className="px-3 py-2.5 text-center font-mono">{b.sixes}</td>
                    <td className="px-4 py-2.5 text-right font-mono text-muted-foreground">{b.strikeRate.toFixed(1)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="px-4 py-2 border-t text-sm text-muted-foreground">
            Extras: {inn.extras.total} (W: {inn.extras.wides}, NB: {inn.extras.noBalls}, B: {inn.extras.byes}, LB: {inn.extras.legByes})
          </div>

          {/* Bowling */}
          <div className="overflow-x-auto border-t">
            <table className="w-full min-w-[400px]">
              <thead><tr className="bg-muted/50 text-xs text-muted-foreground">
                <th className="text-left px-4 py-2">Bowler</th>
                <th className="text-center px-3 py-2">O</th>
                <th className="text-center px-3 py-2">M</th>
                <th className="text-center px-3 py-2">R</th>
                <th className="text-center px-3 py-2">W</th>
                <th className="text-right px-4 py-2">Econ</th>
              </tr></thead>
              <tbody>
                {inn.bowlers.map((b, idx) => (
                  <tr key={b.playerId} className={`border-t text-sm ${idx % 2 === 0 ? '' : 'bg-muted/20'} ${b.isBowling ? 'bg-primary/5' : ''}`}>
                    <td className="px-4 py-2.5 font-medium">{b.playerName} {b.isBowling && <span className="text-primary">*</span>}</td>
                    <td className="px-3 py-2.5 text-center font-mono">{b.overs}.{b.balls % 6}</td>
                    <td className="px-3 py-2.5 text-center font-mono">{b.maidens}</td>
                    <td className="px-3 py-2.5 text-center font-mono">{b.runs}</td>
                    <td className="px-3 py-2.5 text-center font-mono font-bold text-primary">{b.wickets}</td>
                    <td className="px-4 py-2.5 text-right font-mono text-muted-foreground">{b.economy.toFixed(2)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      ))}

      {match.status === 'upcoming' && innings.length === 0 && (
        <div className="text-center py-8 cricket-card text-muted-foreground">
          <Users className="w-10 h-10 mx-auto mb-3 opacity-30" />
          <p>Match hasn't started yet. Set the toss to begin scoring.</p>
        </div>
      )}
    </div>
  );
}

function TeamScoreBlock({ team, innings, align }: { team: Match['teamA']; innings?: Match['innings1']; align: 'left' | 'right' }) {
  return (
    <div className={`flex flex-col ${align === 'right' ? 'items-end text-right' : 'items-start'}`}>
      <div className={`flex items-center gap-2 mb-2 ${align === 'right' ? 'flex-row-reverse' : ''}`}>
        {team.logoURL ? (
          <img src={team.logoURL} alt="" className="w-10 h-10 rounded-full object-cover" />
        ) : (
          <div className="w-10 h-10 rounded-full bg-muted flex items-center justify-center font-bold">{team.name[0]}</div>
        )}
        <p className="font-semibold text-sm truncate max-w-28">{team.name}</p>
      </div>
      {innings ? (
        <>
          <p className="font-display text-3xl font-bold">{innings.runs}/{innings.wickets}</p>
          <p className="text-sm text-muted-foreground">({innings.overs}.{innings.balls} ov) • RR: {innings.runRate?.toFixed(2)}</p>
        </>
      ) : (
        <p className="text-sm text-muted-foreground">Yet to bat</p>
      )}
    </div>
  );
}
