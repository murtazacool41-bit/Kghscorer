'use client';
import { useEffect, useState } from 'react';
import { useParams } from 'next/navigation';
import Link from 'next/link';
import { getPlayer } from '@/lib/services';
import type { Player } from '@/types';
import { ArrowLeft, Activity, Target, Zap, Award } from 'lucide-react';

export default function PlayerPage() {
  const { id } = useParams<{ id: string }>();
  const [player, setPlayer] = useState<Player | null>(null);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState<'batting' | 'bowling' | 'fielding'>('batting');

  useEffect(() => {
    if (id) getPlayer(id).then(setPlayer).finally(() => setLoading(false));
  }, [id]);

  if (loading) return <div className="max-w-4xl mx-auto px-4 py-12 text-center text-muted-foreground">Loading...</div>;
  if (!player) return <div className="max-w-4xl mx-auto px-4 py-12 text-center">Player not found</div>;

  const b = player.battingStats;
  const bw = player.bowlingStats;
  const f = player.fieldingStats;

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-8">
      <Link href="/players" className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground mb-6">
        <ArrowLeft className="w-4 h-4" /> All Players
      </Link>

      {/* Profile Header */}
      <div className="cricket-card p-6 mb-6 bg-gradient-to-br from-cricket-navy/5 to-transparent">
        <div className="flex flex-col sm:flex-row items-center sm:items-start gap-6">
          {player.photoURL ? (
            <img src={player.photoURL} alt={player.name} className="w-24 h-24 rounded-full object-cover ring-4 ring-primary/20" />
          ) : (
            <div className="w-24 h-24 rounded-full bg-gradient-to-br from-primary/30 to-primary/5 flex items-center justify-center ring-4 ring-primary/20">
              <span className="font-display text-4xl font-bold text-primary">{player.name[0]}</span>
            </div>
          )}
          <div className="text-center sm:text-left">
            <h1 className="font-display text-3xl font-bold">{player.name}</h1>
            <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2 mt-2">
              <span className="px-2.5 py-0.5 rounded-full bg-primary/10 text-primary text-xs font-medium">{player.role}</span>
              <span className="px-2.5 py-0.5 rounded-full bg-muted text-xs font-medium">{player.battingStyle}</span>
              {player.bowlingStyle && <span className="px-2.5 py-0.5 rounded-full bg-muted text-xs font-medium">{player.bowlingStyle}</span>}
            </div>
            {player.teamName && (
              <Link href={player.teamId ? `/teams/${player.teamId}` : '#'} className="inline-block mt-2 text-sm text-muted-foreground hover:text-primary transition-colors">
                🏏 {player.teamName}
              </Link>
            )}
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex rounded-xl bg-muted p-1 mb-6 max-w-xs">
        {(['batting', 'bowling', 'fielding'] as const).map(t => (
          <button key={t} onClick={() => setTab(t)} className={`flex-1 py-2 text-xs font-medium rounded-lg transition-all capitalize ${tab === t ? 'bg-background shadow text-foreground' : 'text-muted-foreground'}`}>
            {t}
          </button>
        ))}
      </div>

      {tab === 'batting' && (
        <div>
          {/* Key stats row */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-6">
            <KeyStat label="Runs" value={b.runs} icon={<Activity className="w-4 h-4" />} highlight />
            <KeyStat label="Average" value={b.average.toFixed(2)} icon={<Target className="w-4 h-4" />} />
            <KeyStat label="Strike Rate" value={b.strikeRate.toFixed(2)} icon={<Zap className="w-4 h-4" />} />
            <KeyStat label="Highest" value={`${b.highestScore}${b.highestScoreNotOut ? '*' : ''}`} icon={<Award className="w-4 h-4" />} />
          </div>

          <div className="cricket-card overflow-hidden">
            <table className="w-full">
              <tbody>
                {[
                  ['Matches', b.matches],
                  ['Innings', b.innings],
                  ['Not Outs', b.notOuts],
                  ['Runs', b.runs],
                  ['Highest Score', `${b.highestScore}${b.highestScoreNotOut ? '*' : ''}`],
                  ['Average', b.average.toFixed(2)],
                  ['Strike Rate', b.strikeRate.toFixed(2)],
                  ['50s', b.fifties],
                  ['100s', b.hundreds],
                  ['Fours', b.fours],
                  ['Sixes', b.sixes],
                  ['Ducks', b.ducks],
                ].map(([label, value], i) => (
                  <tr key={String(label)} className={`border-b last:border-0 ${i % 2 === 0 ? 'bg-muted/30' : ''}`}>
                    <td className="px-4 py-3 text-sm text-muted-foreground">{label}</td>
                    <td className="px-4 py-3 text-sm font-semibold font-mono text-right">{value}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {tab === 'bowling' && (
        <div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-6">
            <KeyStat label="Wickets" value={bw.wickets} icon={<Target className="w-4 h-4" />} highlight />
            <KeyStat label="Economy" value={bw.economy.toFixed(2)} icon={<Activity className="w-4 h-4" />} />
            <KeyStat label="Average" value={bw.average.toFixed(2)} icon={<Zap className="w-4 h-4" />} />
            <KeyStat label="Best" value={bw.bestBowlingWickets > 0 ? `${bw.bestBowlingWickets}/${bw.bestBowlingRuns}` : '-'} icon={<Award className="w-4 h-4" />} />
          </div>
          <div className="cricket-card overflow-hidden">
            <table className="w-full">
              <tbody>
                {[
                  ['Matches', bw.matches],
                  ['Innings', bw.innings],
                  ['Overs', bw.overs.toFixed(1)],
                  ['Maidens', bw.maidens],
                  ['Runs', bw.runs],
                  ['Wickets', bw.wickets],
                  ['Best Bowling', bw.bestBowlingWickets > 0 ? `${bw.bestBowlingWickets}/${bw.bestBowlingRuns}` : '-'],
                  ['Economy', bw.economy.toFixed(2)],
                  ['Average', bw.average.toFixed(2)],
                  ['4 Wickets', bw.fourWickets],
                  ['5 Wickets', bw.fiveWickets],
                ].map(([label, value], i) => (
                  <tr key={String(label)} className={`border-b last:border-0 ${i % 2 === 0 ? 'bg-muted/30' : ''}`}>
                    <td className="px-4 py-3 text-sm text-muted-foreground">{label}</td>
                    <td className="px-4 py-3 text-sm font-semibold font-mono text-right">{value}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {tab === 'fielding' && (
        <div className="grid sm:grid-cols-3 gap-4">
          <KeyStat label="Catches" value={f.catches} icon={<Award className="w-4 h-4" />} highlight />
          <KeyStat label="Run Outs" value={f.runOuts} icon={<Zap className="w-4 h-4" />} />
          <KeyStat label="Stumpings" value={f.stumpings} icon={<Target className="w-4 h-4" />} />
        </div>
      )}
    </div>
  );
}

function KeyStat({ label, value, icon, highlight }: { label: string; value: string | number; icon: React.ReactNode; highlight?: boolean }) {
  return (
    <div className={`cricket-card p-4 text-center ${highlight ? 'border-primary/30 bg-primary/5' : ''}`}>
      <div className={`w-8 h-8 rounded-lg flex items-center justify-center mx-auto mb-2 ${highlight ? 'bg-primary/20 text-primary' : 'bg-muted text-muted-foreground'}`}>
        {icon}
      </div>
      <p className="font-display text-2xl font-bold">{value}</p>
      <p className="text-xs text-muted-foreground mt-0.5">{label}</p>
    </div>
  );
}
