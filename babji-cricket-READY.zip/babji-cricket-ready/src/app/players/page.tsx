'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { getAllPlayers } from '@/lib/services';
import type { Player } from '@/types';
import { Search, User } from 'lucide-react';

export default function PlayersPage() {
  const [players, setPlayers] = useState<Player[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [roleFilter, setRoleFilter] = useState('All');

  useEffect(() => {
    getAllPlayers().then(setPlayers).finally(() => setLoading(false));
  }, []);

  const roles = ['All', 'Batsman', 'Bowler', 'All Rounder', 'Wicket Keeper'];
  const filtered = players
    .filter(p => roleFilter === 'All' || p.role === roleFilter)
    .filter(p => p.name.toLowerCase().includes(search.toLowerCase()));

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
      <div className="mb-6">
        <h1 className="font-display text-3xl font-bold">Players</h1>
        <p className="text-muted-foreground mt-1">{players.length} players registered</p>
      </div>

      <div className="flex flex-col sm:flex-row gap-3 mb-6">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search players..." className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-input bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring" />
        </div>
        <div className="flex gap-2 flex-wrap">
          {roles.map(r => (
            <button key={r} onClick={() => setRoleFilter(r)} className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-colors ${roleFilter === r ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground hover:text-foreground'}`}>{r}</button>
          ))}
        </div>
      </div>

      {loading ? (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {Array.from({ length: 8 }).map((_, i) => <div key={i} className="cricket-card p-4 h-24 skeleton" />)}
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-16">
          <User className="w-12 h-12 text-muted-foreground/30 mx-auto mb-4" />
          <p className="text-muted-foreground">No players found</p>
        </div>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {filtered.map(player => (
            <Link key={player.id} href={`/players/${player.id}`}>
              <div className="cricket-card p-4 hover:border-primary/30 transition-all">
                <div className="flex items-center gap-3">
                  {player.photoURL ? (
                    <img src={player.photoURL} alt={player.name} className="w-12 h-12 rounded-full object-cover" />
                  ) : (
                    <div className="w-12 h-12 rounded-full bg-gradient-to-br from-primary/20 to-muted flex items-center justify-center font-bold text-primary text-lg">{player.name[0]}</div>
                  )}
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold truncate">{player.name}</p>
                    <p className="text-xs text-muted-foreground">{player.role}</p>
                    {player.teamName && <p className="text-xs text-muted-foreground truncate">🏏 {player.teamName}</p>}
                  </div>
                </div>
                <div className="grid grid-cols-3 gap-2 mt-3 pt-3 border-t text-center">
                  <div><p className="font-mono font-bold text-sm">{player.battingStats.runs}</p><p className="text-xs text-muted-foreground">Runs</p></div>
                  <div><p className="font-mono font-bold text-sm">{player.bowlingStats.wickets}</p><p className="text-xs text-muted-foreground">Wkts</p></div>
                  <div><p className="font-mono font-bold text-sm">{player.battingStats.matches}</p><p className="text-xs text-muted-foreground">M</p></div>
                </div>
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
