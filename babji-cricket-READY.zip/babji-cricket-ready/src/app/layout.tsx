import type { Metadata } from 'next';
import { AuthProvider } from '@/lib/auth-context';
import Navbar from '@/components/layout/Navbar';
import { Toaster } from 'react-hot-toast';
import './globals.css';

export const metadata: Metadata = {
  title: 'Babji Cricket - Gully Cricket App',
  description: 'Track live scores, teams, players and tournaments for local cricket',
  keywords: 'cricket, gully cricket, live score, local cricket, scorecard',
  openGraph: {
    title: 'Babji Cricket',
    description: 'Your neighborhood cricket companion',
    type: 'website',
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link href="https://fonts.googleapis.com/css2?family=Rajdhani:wght@400;500;600;700&family=DM+Sans:ital,opsz,wght@0,9..40,300;0,9..40,400;0,9..40,500;0,9..40,600;1,9..40,400&family=JetBrains+Mono:wght@400;600&display=swap" rel="stylesheet" />
      </head>
      <body className="font-body bg-background text-foreground antialiased">
        <AuthProvider>
          <Navbar />
          <main className="min-h-screen pt-16">
            {children}
          </main>
          <Toaster
            position="top-right"
            toastOptions={{
              style: { background: '#0A1628', color: '#fff', border: '1px solid #FFD700' },
            }}
          />
        </AuthProvider>
      </body>
    </html>
  );
}
