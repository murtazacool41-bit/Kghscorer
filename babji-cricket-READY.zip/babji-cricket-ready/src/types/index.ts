import { Timestamp } from 'firebase/firestore';

export type UserRole = 'admin' | 'scorer' | 'user';

export interface User {
  id: string;
  email: string;
  displayName: string;
  photoURL?: string;
  role: UserRole;
  createdAt: Timestamp;
  teamsJoined?: string[];
}

export interface Team {
  id: string;
  name: string;
  logoURL?: string;
  captainId: string;
  captainName: string;
  description?: string;
  playerIds: string[];
  createdBy: string;
  createdAt: Timestamp;
  stats: TeamStats;
}

export interface TeamStats {
  matchesPlayed: number;
  wins: number;
  losses: number;
  ties: number;
  noResult: number;
  winPercentage: number;
  runsScored: number;
  wicketsTaken: number;
}

export type BattingStyle = 'Right Handed' | 'Left Handed';
export type BowlingStyle = 'Right Arm Fast' | 'Right Arm Medium' | 'Right Arm Off Spin' | 'Right Arm Leg Spin' | 'Left Arm Fast' | 'Left Arm Medium' | 'Left Arm Orthodox' | 'Left Arm Chinaman';
export type PlayerRole = 'Batsman' | 'Bowler' | 'All Rounder' | 'Wicket Keeper';

export interface Player {
  id: string;
  name: string;
  photoURL?: string;
  battingStyle: BattingStyle;
  bowlingStyle?: BowlingStyle;
  role: PlayerRole;
  teamId?: string;
  teamName?: string;
  userId?: string;
  createdBy: string;
  createdAt: Timestamp;
  battingStats: BattingStats;
  bowlingStats: BowlingStats;
  fieldingStats: FieldingStats;
}

export interface BattingStats {
  matches: number;
  innings: number;
  runs: number;
  highestScore: number;
  highestScoreNotOut: boolean;
  notOuts: number;
  average: number;
  strikeRate: number;
  fours: number;
  sixes: number;
  fifties: number;
  hundreds: number;
  ducks: number;
}

export interface BowlingStats {
  matches: number;
  innings: number;
  overs: number;
  balls: number;
  maidens: number;
  runs: number;
  wickets: number;
  bestBowlingWickets: number;
  bestBowlingRuns: number;
  average: number;
  economy: number;
  strikeRate: number;
  fourWickets: number;
  fiveWickets: number;
}

export interface FieldingStats {
  catches: number;
  runOuts: number;
  stumpings: number;
}

export type TournamentFormat = 'league' | 'knockout' | 'group+knockout';
export type TournamentStatus = 'upcoming' | 'ongoing' | 'completed';

export interface Tournament {
  id: string;
  name: string;
  logoURL?: string;
  startDate: Timestamp;
  endDate: Timestamp;
  format: TournamentFormat;
  status: TournamentStatus;
  teamIds: string[];
  overs: number;
  createdBy: string;
  createdAt: Timestamp;
  description?: string;
  location?: string;
  numberOfGroups?: number;
  teamsPerGroup?: number;
}

export type MatchStatus = 'upcoming' | 'toss' | 'live' | 'innings_break' | 'completed' | 'abandoned';
export type TossDecision = 'bat' | 'bowl';

export interface Match {
  id: string;
  teamA: { id: string; name: string; logoURL?: string };
  teamB: { id: string; name: string; logoURL?: string };
  ground: string;
  date: Timestamp;
  overs: number;
  tournamentId?: string;
  tournamentName?: string;
  status: MatchStatus;
  tossWinnerId?: string;
  tossWinnerName?: string;
  tossDecision?: TossDecision;
  battingFirstTeamId?: string;
  playingXIA?: string[];
  playingXIB?: string[];
  currentInnings: number;
  innings1?: InningsSummary;
  innings2?: InningsSummary;
  result?: MatchResult;
  createdBy: string;
  scorerId?: string;
  createdAt: Timestamp;
}

export interface InningsSummary {
  teamId: string;
  teamName: string;
  runs: number;
  wickets: number;
  overs: number;
  balls: number;
  extras: Extras;
  runRate: number;
  isCompleted: boolean;
}

export interface Extras {
  wides: number;
  noBalls: number;
  byes: number;
  legByes: number;
  total: number;
}

export interface MatchResult {
  winnerId: string;
  winnerName: string;
  resultText: string;
  margin?: number;
  marginType?: 'runs' | 'wickets';
}

export interface Innings {
  id: string;
  matchId: string;
  inningsNumber: number;
  battingTeamId: string;
  bowlingTeamId: string;
  runs: number;
  wickets: number;
  overs: number;
  balls: number;
  extras: Extras;
  runRate: number;
  targetRuns?: number;
  requiredRunRate?: number;
  isCompleted: boolean;
  batters: BatterInnings[];
  bowlers: BowlerInnings[];
  partnerships: Partnership[];
  fallOfWickets: FallOfWicket[];
  currentBatterIds: string[];
  currentBowlerId: string;
  strikerBatterId: string;
  nonStrikerBatterId: string;
}

export interface BatterInnings {
  playerId: string;
  playerName: string;
  runs: number;
  balls: number;
  fours: number;
  sixes: number;
  strikeRate: number;
  dismissalType?: DismissalType;
  dismissalDesc?: string;
  bowlerId?: string;
  bowlerName?: string;
  fielderId?: string;
  fielderName?: string;
  battingOrder: number;
  isOut: boolean;
  isOnStrike?: boolean;
}

export interface BowlerInnings {
  playerId: string;
  playerName: string;
  overs: number;
  balls: number;
  maidens: number;
  runs: number;
  wickets: number;
  wides: number;
  noBalls: number;
  economy: number;
  bowlingOrder: number;
  isBowling?: boolean;
}

export interface Partnership {
  batter1Id: string;
  batter1Name: string;
  batter2Id: string;
  batter2Name: string;
  runs: number;
  balls: number;
  wicketNumber: number;
}

export interface FallOfWicket {
  wicketNumber: number;
  runs: number;
  overs: string;
  playerId: string;
  playerName: string;
}

export type DismissalType = 'bowled' | 'caught' | 'run_out' | 'lbw' | 'stumped' | 'hit_wicket' | 'retired_hurt' | 'obstructing_field';

export type BallEventType = 'normal' | 'wide' | 'no_ball' | 'bye' | 'leg_bye' | 'wicket';

export interface BallEvent {
  id: string;
  matchId: string;
  inningsId: string;
  inningsNumber: number;
  overNumber: number;
  ballNumber: number;
  batsmanId: string;
  batsmanName: string;
  bowlerId: string;
  bowlerName: string;
  runs: number;
  extraType?: 'wide' | 'no_ball' | 'bye' | 'leg_bye';
  extraRuns: number;
  isWicket: boolean;
  dismissalType?: DismissalType;
  dismissedPlayerId?: string;
  dismissedPlayerName?: string;
  fielderId?: string;
  fielderName?: string;
  isBoundary: boolean;
  isSix: boolean;
  timestamp: Timestamp;
  totalRuns: number;
}

export interface PointsTableEntry {
  id: string;
  tournamentId: string;
  teamId: string;
  teamName: string;
  teamLogoURL?: string;
  group?: string;
  matchesPlayed: number;
  wins: number;
  losses: number;
  ties: number;
  noResult: number;
  points: number;
  runsScored: number;
  runsConceded: number;
  oversFaced: number;
  oversBowled: number;
  netRunRate: number;
}

export interface LeaderboardEntry {
  playerId: string;
  playerName: string;
  playerPhotoURL?: string;
  teamId?: string;
  teamName?: string;
  value: number;
  label: string;
}
